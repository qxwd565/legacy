Shader "Custom/Card/Unlit_2Texture2uv" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondTint ("Second Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _BlendIntensity ("Blend Intensity", Float) = 2
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" "Highlight"="True" }
 Pass {
  Tags { "RenderType"="Opaque" "Highlight"="True" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform highp vec4 _SecondTex_ST;
uniform highp vec4 _MainTex_ST;
uniform mediump float _LightingBlend;
uniform lowp vec4 _Color;
uniform lowp vec4 _LightColor0;
uniform highp vec4 glstate_lightmodel_ambient;
uniform highp mat4 glstate_matrix_mvp;
attribute vec4 _glesMultiTexCoord1;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesColor;
attribute vec4 _glesVertex;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = (mix (_glesColor, ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend)) * _Color);
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((_glesMultiTexCoord1.xy * _SecondTex_ST.xy) + _SecondTex_ST.zw);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform mediump float _BlendIntensity;
uniform lowp vec4 _SecondTint;
uniform sampler2D _SecondTex;
uniform sampler2D _MainTex;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 main_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  main_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_SecondTex, xlv_TEXCOORD1);
  mediump vec4 tmpvar_5;
  tmpvar_5 = ((tmpvar_4 * _SecondTint) * _BlendIntensity);
  mediump vec4 tmpvar_6;
  tmpvar_6 = mix (main_2, (main_2 * tmpvar_5), tmpvar_5.wwww);
  mediump vec4 tmpvar_7;
  tmpvar_7 = min (((tmpvar_6 + 0.15) * xlv_COLOR), tmpvar_6);
  tmpvar_1 = tmpvar_7;
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback "Diffuse"
}