Shader "Custom/Card/Unlit_Desaturate_2Texture2uv" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondTint ("Second Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _BlendIntensity ("Blend Intensity", Float) = 2
 _DarkColor ("Dark Color", Color) = (0.3,0.3,0.3,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" "Highlight"="True" }
 Pass {
  Tags { "RenderType"="Opaque" "Highlight"="True" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform highp vec4 _SecondTex_ST;
uniform highp vec4 _MainTex_ST;
uniform mediump float _LightingBlend;
uniform lowp vec4 _Color;
uniform lowp vec4 _LightColor0;
uniform highp vec4 glstate_lightmodel_ambient;
uniform highp mat4 glstate_matrix_mvp;
attribute vec4 _glesMultiTexCoord1;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesColor;
attribute vec4 _glesVertex;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = (mix (_glesColor, ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend)) * _Color);
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((_glesMultiTexCoord1.xy * _SecondTex_ST.xy) + _SecondTex_ST.zw);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform lowp vec4 _AvgLum;
uniform highp float _Intensity;
uniform highp float _Contrast;
uniform mediump float _Desaturate;
uniform lowp vec4 _DarkColor;
uniform mediump float _BlendIntensity;
uniform lowp vec4 _SecondTint;
uniform sampler2D _SecondTex;
uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 main_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0);
  main_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_SecondTex, xlv_TEXCOORD1);
  mediump vec4 tmpvar_6;
  tmpvar_6 = ((tmpvar_5 * _SecondTint) * _BlendIntensity);
  mediump vec4 tmpvar_7;
  tmpvar_7 = mix (main_3, (main_3 * tmpvar_6), tmpvar_6.wwww);
  mediump vec4 tmpvar_8;
  tmpvar_8 = mix (tmpvar_7, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), tmpvar_7.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_9;
  tmpvar_9 = mix (tmpvar_8, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_9;
  mediump vec4 tmpvar_10;
  tmpvar_10 = min (((col_2 + 0.15) * xlv_COLOR), col_2);
  tmpvar_1 = (tmpvar_10 * _Intensity);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback "Diffuse"
}