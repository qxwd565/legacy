Shader "Hero/AddMultiplyFXScrolling" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "white" {}
 _FxIntensity ("FX Intensity", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Vector 6 [_Time]
Vector 7 [_LightColor0]
Vector 8 [_Color]
Float 9 [_ScrollX]
Float 10 [_ScrollY]
Float 11 [_ScaleX]
Float 12 [_ScaleY]
Float 13 [_LightingBlend]
Vector 14 [_MainTex_ST]
"!!ARBvp1.0
# 19 ALU
PARAM c[15] = { { 2 },
		state.lightmodel.ambient,
		state.matrix.mvp,
		program.local[6..14] };
TEMP R0;
TEMP R1;
MOV R0.x, c[0];
MUL R0, R0.x, c[1];
ADD R0, R0, c[7];
MUL R0, R0, vertex.color;
ADD R0, R0, -vertex.color;
MAD R1, R0, c[13].x, vertex.color;
MAD R0.xy, vertex.texcoord[0], c[14], c[14].zwzw;
MOV R0.z, c[9].x;
MOV R0.w, c[10].x;
MUL R0.z, R0, c[6].x;
MUL R0.w, R0, c[6].x;
MUL result.color, R1, c[8].w;
MOV result.texcoord[0].xy, R0;
MAD result.texcoord[1].x, R0, c[11], R0.z;
MAD result.texcoord[1].y, R0, c[12].x, R0.w;
DP4 result.position.w, vertex.position, c[5];
DP4 result.position.z, vertex.position, c[4];
DP4 result.position.y, vertex.position, c[3];
DP4 result.position.x, vertex.position, c[2];
END
# 19 instructions, 2 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Matrix 0 [glstate_matrix_mvp]
Vector 4 [glstate_lightmodel_ambient]
Vector 5 [_Time]
Vector 6 [_LightColor0]
Vector 7 [_Color]
Float 8 [_ScrollX]
Float 9 [_ScrollY]
Float 10 [_ScaleX]
Float 11 [_ScaleY]
Float 12 [_LightingBlend]
Vector 13 [_MainTex_ST]
"vs_2_0
; 19 ALU
def c14, 2.00000000, 0, 0, 0
dcl_position0 v0
dcl_texcoord0 v1
dcl_color0 v2
mov r0, c4
mul r0, c14.x, r0
add r0, r0, c6
mul r0, r0, v2
add r0, r0, -v2
mad r1, r0, c12.x, v2
mad r0.xy, v1, c13, c13.zwzw
mov r0.z, c5.x
mov r0.w, c5.x
mul r0.z, c8.x, r0
mul r0.w, c9.x, r0
mul oD0, r1, c7.w
mov oT0.xy, r0
mad oT1.x, r0, c10, r0.z
mad oT1.y, r0, c11.x, r0.w
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Vector 48 [_Color]
Float 72 [_ScrollX]
Float 76 [_ScrollY]
Float 80 [_ScaleX]
Float 84 [_ScaleY]
Float 88 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
BindCB  "UnityPerFrame" 3
"vs_4_0
eefiecedoifafocblhbaelejfdlcamedfadogmimabaaaaaakiadaaaaadaaaaaa
cmaaaaaajmaaaaaaciabaaaaejfdeheogiaaaaaaadaaaaaaaiaaaaaafaaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaagcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apapaaaafaepfdejfeejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheo
ieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaa
apaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaa
abaaaaaaaaaaaaaaadaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaacaaaaaaapaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfcee
aaedepemepfcaaklfdeieefchiacaaaaeaaaabaajoaaaaaafjaaaaaeegiocaaa
aaaaaaaaahaaaaaafjaaaaaeegiocaaaabaaaaaaabaaaaaafjaaaaaeegiocaaa
acaaaaaaaeaaaaaafjaaaaaeegiocaaaadaaaaaaafaaaaaafpaaaaadpcbabaaa
aaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaadpcbabaaaacaaaaaaghaaaaae
pccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaaabaaaaaagfaaaaadmccabaaa
abaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaacabaaaaaadiaaaaaipcaabaaa
aaaaaaaafgbfbaaaaaaaaaaaegiocaaaacaaaaaaabaaaaaadcaaaaakpcaabaaa
aaaaaaaaegiocaaaacaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaaaaaaaaaa
dcaaaaakpcaabaaaaaaaaaaaegiocaaaacaaaaaaacaaaaaakgbkbaaaaaaaaaaa
egaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaacaaaaaaadaaaaaa
pgbpbaaaaaaaaaaaegaobaaaaaaaaaaadiaaaaajdcaabaaaaaaaaaaaogikcaaa
aaaaaaaaaeaaaaaaagiacaaaabaaaaaaaaaaaaaadcaaaaalmcaabaaaaaaaaaaa
agbebaaaabaaaaaaagiecaaaaaaaaaaaagaaaaaakgiocaaaaaaaaaaaagaaaaaa
dcaaaaakmccabaaaabaaaaaakgaobaaaaaaaaaaaagiecaaaaaaaaaaaafaaaaaa
agaebaaaaaaaaaaadgaaaaafdccabaaaabaaaaaaogakbaaaaaaaaaaadcaaaaao
pcaabaaaaaaaaaaaegiocaaaadaaaaaaaeaaaaaaaceaaaaaaaaaaaeaaaaaaaea
aaaaaaeaaaaaaaeaegiocaaaaaaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaa
egaobaaaaaaaaaaaegbobaaaacaaaaaaegbobaiaebaaaaaaacaaaaaadcaaaaak
pcaabaaaaaaaaaaakgikcaaaaaaaaaaaafaaaaaaegaobaaaaaaaaaaaegbobaaa
acaaaaaadiaaaaaipccabaaaacaaaaaaegaobaaaaaaaaaaapgipcaaaaaaaaaaa
adaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Vector 48 [_Color]
Float 72 [_ScrollX]
Float 76 [_ScrollY]
Float 80 [_ScaleX]
Float 84 [_ScaleY]
Float 88 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
BindCB  "UnityPerFrame" 3
"vs_4_0_level_9_1
eefiecedkchkgjjbabbponafphioefngpcheclinabaaaaaahmafaaaaaeaaaaaa
daaaaaaaaaacaaaaiaaeaaaapaaeaaaaebgpgodjmiabaaaamiabaaaaaaacpopp
geabaaaageaaaaaaafaaceaaaaaagaaaaaaagaaaaaaaceaaabaagaaaaaaaabaa
abaaabaaaaaaaaaaaaaaadaaaeaaacaaaaaaaaaaabaaaaaaabaaagaaaaaaaaaa
acaaaaaaaeaaahaaaaaaaaaaadaaaeaaabaaalaaaaaaaaaaaaaaaaaaaaacpopp
fbaaaaafamaaapkaaaaaaaeaaaaaaaaaaaaaaaaaaaaaaaaabpaaaaacafaaaaia
aaaaapjabpaaaaacafaaabiaabaaapjabpaaaaacafaaaciaacaaapjaabaaaaac
aaaaabiaagaaaakaafaaaaadaaaaadiaaaaaaaiaadaaolkaaeaaaaaeaaaaamia
abaaeejaafaaeekaafaaoekaaeaaaaaeaaaaamoaaaaaleiaaeaabekaaaaaeeia
abaaaaacaaaaadoaaaaaooiaabaaaaacaaaaapiaalaaoekaabaaaaacabaaabia
amaaaakaaeaaaaaeaaaaapiaaaaaoeiaabaaaaiaabaaoekaaeaaaaaeaaaaapia
aaaaoeiaacaaoejaacaaoejbaeaaaaaeaaaaapiaaeaakkkaaaaaoeiaacaaoeja
afaaaaadabaaapoaaaaaoeiaacaappkaafaaaaadaaaaapiaaaaaffjaaiaaoeka
aeaaaaaeaaaaapiaahaaoekaaaaaaajaaaaaoeiaaeaaaaaeaaaaapiaajaaoeka
aaaakkjaaaaaoeiaaeaaaaaeaaaaapiaakaaoekaaaaappjaaaaaoeiaaeaaaaae
aaaaadmaaaaappiaaaaaoekaaaaaoeiaabaaaaacaaaaammaaaaaoeiappppaaaa
fdeieefchiacaaaaeaaaabaajoaaaaaafjaaaaaeegiocaaaaaaaaaaaahaaaaaa
fjaaaaaeegiocaaaabaaaaaaabaaaaaafjaaaaaeegiocaaaacaaaaaaaeaaaaaa
fjaaaaaeegiocaaaadaaaaaaafaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaad
dcbabaaaabaaaaaafpaaaaadpcbabaaaacaaaaaaghaaaaaepccabaaaaaaaaaaa
abaaaaaagfaaaaaddccabaaaabaaaaaagfaaaaadmccabaaaabaaaaaagfaaaaad
pccabaaaacaaaaaagiaaaaacabaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaa
aaaaaaaaegiocaaaacaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaa
acaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaa
aaaaaaaaegiocaaaacaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaa
dcaaaaakpccabaaaaaaaaaaaegiocaaaacaaaaaaadaaaaaapgbpbaaaaaaaaaaa
egaobaaaaaaaaaaadiaaaaajdcaabaaaaaaaaaaaogikcaaaaaaaaaaaaeaaaaaa
agiacaaaabaaaaaaaaaaaaaadcaaaaalmcaabaaaaaaaaaaaagbebaaaabaaaaaa
agiecaaaaaaaaaaaagaaaaaakgiocaaaaaaaaaaaagaaaaaadcaaaaakmccabaaa
abaaaaaakgaobaaaaaaaaaaaagiecaaaaaaaaaaaafaaaaaaagaebaaaaaaaaaaa
dgaaaaafdccabaaaabaaaaaaogakbaaaaaaaaaaadcaaaaaopcaabaaaaaaaaaaa
egiocaaaadaaaaaaaeaaaaaaaceaaaaaaaaaaaeaaaaaaaeaaaaaaaeaaaaaaaea
egiocaaaaaaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegaobaaaaaaaaaaa
egbobaaaacaaaaaaegbobaiaebaaaaaaacaaaaaadcaaaaakpcaabaaaaaaaaaaa
kgikcaaaaaaaaaaaafaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaadiaaaaai
pccabaaaacaaaaaaegaobaaaaaaaaaaapgipcaaaaaaaaaaaadaaaaaadoaaaaab
ejfdeheogiaaaaaaadaaaaaaaiaaaaaafaaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
aaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadadaaaa
gcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafaepfdejfeejepeo
aafeeffiedepepfceeaaedepemepfcaaepfdeheoieaaaaaaaeaaaaaaaiaaaaaa
giaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaa
abaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapaaaaaa
fdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Vector 0 [_Color]
Float 1 [_Intensity]
Float 2 [_FxIntensity]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FxTex] 2D 1
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 10 ALU, 2 TEX
PARAM c[4] = { program.local[0..2],
		{ 2 } };
TEMP R0;
TEMP R1;
TEMP R2;
TEX R0, fragment.texcoord[0], texture[0], 2D;
TEX R1, fragment.texcoord[1], texture[1], 2D;
ADD R2.x, -R0.w, c[0].w;
MUL R0.w, R0, R2.x;
MUL R1, R1, c[2].x;
MUL R0.xyz, R0, c[0];
MUL R0, R0, R1;
MUL R0, R0, c[1].x;
MUL R0, R0, fragment.color.primary;
MUL result.color, R0, c[3].x;
END
# 10 instructions, 3 R-regs
"
}
SubProgram "d3d9 " {
Vector 0 [_Color]
Float 1 [_Intensity]
Float 2 [_FxIntensity]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FxTex] 2D 1
"ps_2_0
; 9 ALU, 2 TEX
dcl_2d s0
dcl_2d s1
def c3, 2.00000000, 0, 0, 0
dcl t0.xy
dcl t1.xy
dcl v0
texld r0, t0, s0
texld r1, t1, s1
add_pp r2.x, -r0.w, c0.w
mul_pp r0.w, r0, r2.x
mul r1, r1, c2.x
mul_pp r0.xyz, r0, c0
mul_pp r0, r0, r1
mul r0, r0, c1.x
mul r0, r0, v0
mul r0, r0, c3.x
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FxTex] 2D 1
ConstBuffer "$Globals" 112
Vector 48 [_Color]
Float 64 [_Intensity]
Float 68 [_FxIntensity]
BindCB  "$Globals" 0
"ps_4_0
eefiecedmonlpobfkmgnpmhllojnlepnilmgdehcabaaaaaalmacaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcmiabaaaaeaaaaaaahcaaaaaafjaaaaae
egiocaaaaaaaaaaaafaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaa
abaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaa
ffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaadmcbabaaaabaaaaaagcbaaaad
pcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacadaaaaaaefaaaaaj
pcaabaaaaaaaaaaaogbkbaaaabaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaa
diaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaafgifcaaaaaaaaaaaaeaaaaaa
efaaaaajpcaabaaaabaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaa
aaaaaaaaaaaaaaajbcaabaaaacaaaaaadkaabaiaebaaaaaaabaaaaaadkiacaaa
aaaaaaaaadaaaaaadiaaaaahicaabaaaacaaaaaadkaabaaaabaaaaaaakaabaaa
acaaaaaadiaaaaaihcaabaaaacaaaaaaegacbaaaabaaaaaaegiccaaaaaaaaaaa
adaaaaaadiaaaaahpcaabaaaaaaaaaaaegaobaaaaaaaaaaaegaobaaaacaaaaaa
aaaaaaahpcaabaaaaaaaaaaaegaobaaaaaaaaaaaegaobaaaaaaaaaaadiaaaaai
pcaabaaaaaaaaaaaegaobaaaaaaaaaaaagiacaaaaaaaaaaaaeaaaaaadiaaaaah
pccabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FxTex] 2D 1
ConstBuffer "$Globals" 112
Vector 48 [_Color]
Float 64 [_Intensity]
Float 68 [_FxIntensity]
BindCB  "$Globals" 0
"ps_4_0_level_9_1
eefiecedbahabjgdopafcgadippllkfmncobehjfabaaaaaapaadaaaaaeaaaaaa
daaaaaaagaabaaaadaadaaaalmadaaaaebgpgodjciabaaaaciabaaaaaaacpppp
paaaaaaadiaaaaaaabaacmaaaaaadiaaaaaadiaaacaaceaaaaaadiaaaaaaaaaa
abababaaaaaaadaaacaaaaaaaaaaaaaaaaacppppbpaaaaacaaaaaaiaaaaaapla
bpaaaaacaaaaaaiaabaaaplabpaaaaacaaaaaajaaaaiapkabpaaaaacaaaaaaja
abaiapkaabaaaaacaaaaadiaaaaabllaecaaaaadaaaaapiaaaaaoeiaabaioeka
ecaaaaadabaacpiaaaaaoelaaaaioekaafaaaaadaaaacpiaaaaaoeiaabaaffka
acaaaaadacaaciiaabaappibaaaappkaafaaaaadacaaciiaabaappiaacaappia
afaaaaadacaachiaabaaoeiaaaaaoekaafaaaaadaaaaapiaaaaaoeiaacaaoeia
afaaaaadaaaaapiaaaaaoeiaabaaaakaafaaaaadaaaaapiaaaaaoeiaabaaoela
acaaaaadaaaacpiaaaaaoeiaaaaaoeiaabaaaaacaaaicpiaaaaaoeiappppaaaa
fdeieefcmiabaaaaeaaaaaaahcaaaaaafjaaaaaeegiocaaaaaaaaaaaafaaaaaa
fkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaaabaaaaaafibiaaaeaahabaaa
aaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaaffffaaaagcbaaaaddcbabaaa
abaaaaaagcbaaaadmcbabaaaabaaaaaagcbaaaadpcbabaaaacaaaaaagfaaaaad
pccabaaaaaaaaaaagiaaaaacadaaaaaaefaaaaajpcaabaaaaaaaaaaaogbkbaaa
abaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaadiaaaaaipcaabaaaaaaaaaaa
egaobaaaaaaaaaaafgifcaaaaaaaaaaaaeaaaaaaefaaaaajpcaabaaaabaaaaaa
egbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaaaaaaaaajbcaabaaa
acaaaaaadkaabaiaebaaaaaaabaaaaaadkiacaaaaaaaaaaaadaaaaaadiaaaaah
icaabaaaacaaaaaadkaabaaaabaaaaaaakaabaaaacaaaaaadiaaaaaihcaabaaa
acaaaaaaegacbaaaabaaaaaaegiccaaaaaaaaaaaadaaaaaadiaaaaahpcaabaaa
aaaaaaaaegaobaaaaaaaaaaaegaobaaaacaaaaaaaaaaaaahpcaabaaaaaaaaaaa
egaobaaaaaaaaaaaegaobaaaaaaaaaaadiaaaaaipcaabaaaaaaaaaaaegaobaaa
aaaaaaaaagiacaaaaaaaaaaaaeaaaaaadiaaaaahpccabaaaaaaaaaaaegaobaaa
aaaaaaaaegbobaaaacaaaaaadoaaaaabejfdeheoieaaaaaaaeaaaaaaaiaaaaaa
giaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaa
abaaaaaaamamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaa
fdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheo
cmaaaaaaabaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaa
apaaaaaafdfgfpfegbhcghgfheaaklkl"
}
}
 }
}
Fallback Off
}