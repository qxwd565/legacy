Shader "Custom/Card/Unlit_Desaturate_2Texture2uv" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondTint ("Second Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _BlendIntensity ("Blend Intensity", Float) = 2
 _DarkColor ("Dark Color", Color) = (0.3,0.3,0.3,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" "Highlight"="True" }
 Pass {
  Tags { "RenderType"="Opaque" "Highlight"="True" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
Vector 6 [_LightColor0]
Vector 7 [_Color]
Float 8 [_LightingBlend]
Vector 9 [_MainTex_ST]
Vector 10 [_SecondTex_ST]
"!!ARBvp1.0
# 12 ALU
PARAM c[11] = { { 2 },
		state.lightmodel.ambient,
		state.matrix.mvp,
		program.local[6..10] };
TEMP R0;
MOV R0.x, c[0];
MUL R0, R0.x, c[1];
ADD R0, R0, c[6];
ADD R0, R0, -vertex.color;
MAD R0, R0, c[8].x, vertex.color;
MUL result.color, R0, c[7];
MAD result.texcoord[0].xy, vertex.texcoord[0], c[9], c[9].zwzw;
MAD result.texcoord[1].xy, vertex.texcoord[1], c[10], c[10].zwzw;
DP4 result.position.w, vertex.position, c[5];
DP4 result.position.z, vertex.position, c[4];
DP4 result.position.y, vertex.position, c[3];
DP4 result.position.x, vertex.position, c[2];
END
# 12 instructions, 1 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
Matrix 0 [glstate_matrix_mvp]
Vector 4 [glstate_lightmodel_ambient]
Vector 5 [_LightColor0]
Vector 6 [_Color]
Float 7 [_LightingBlend]
Vector 8 [_MainTex_ST]
Vector 9 [_SecondTex_ST]
"vs_2_0
; 12 ALU
def c10, 2.00000000, 0, 0, 0
dcl_position0 v0
dcl_texcoord0 v1
dcl_texcoord1 v2
dcl_color0 v3
mov r0, c4
mul r0, c10.x, r0
add r0, r0, c5
add r0, r0, -v3
mad r0, r0, c7.x, v3
mul oD0, r0, c6
mad oT0.xy, v1, c8, c8.zwzw
mad oT1.xy, v2, c9, c9.zwzw
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
ConstBuffer "$Globals" 192
Vector 16 [_LightColor0]
Vector 48 [_Color]
Float 144 [_LightingBlend]
Vector 160 [_MainTex_ST]
Vector 176 [_SecondTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
BindCB  "UnityPerFrame" 2
"vs_4_0
eefiecedgaeljjkpiehdldhkbnbomhcmhakioninabaaaaaaiaadaaaaadaaaaaa
cmaaaaaaleaaaaaaeaabaaaaejfdeheoiaaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaahbaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaahbaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaa
adadaaaahkaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaapapaaaafaepfdej
feejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheoieaaaaaaaeaaaaaa
aiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaaaaaaaaaa
adaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaakl
fdeieefcdiacaaaaeaaaabaaioaaaaaafjaaaaaeegiocaaaaaaaaaaaamaaaaaa
fjaaaaaeegiocaaaabaaaaaaaeaaaaaafjaaaaaeegiocaaaacaaaaaaafaaaaaa
fpaaaaadpcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaaddcbabaaa
acaaaaaafpaaaaadpcbabaaaadaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaa
gfaaaaaddccabaaaabaaaaaagfaaaaadmccabaaaabaaaaaagfaaaaadpccabaaa
acaaaaaagiaaaaacabaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaa
egiocaaaabaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaa
aaaaaaaaagbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaa
egiocaaaabaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaak
pccabaaaaaaaaaaaegiocaaaabaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaa
aaaaaaaadcaaaaaldccabaaaabaaaaaaegbabaaaabaaaaaaegiacaaaaaaaaaaa
akaaaaaaogikcaaaaaaaaaaaakaaaaaadcaaaaalmccabaaaabaaaaaaagbebaaa
acaaaaaaagiecaaaaaaaaaaaalaaaaaakgiocaaaaaaaaaaaalaaaaaadcaaaaao
pcaabaaaaaaaaaaaegiocaaaacaaaaaaaeaaaaaaaceaaaaaaaaaaaeaaaaaaaea
aaaaaaeaaaaaaaeaegiocaaaaaaaaaaaabaaaaaaaaaaaaaipcaabaaaaaaaaaaa
egaobaaaaaaaaaaaegbobaiaebaaaaaaadaaaaaadcaaaaakpcaabaaaaaaaaaaa
agiacaaaaaaaaaaaajaaaaaaegaobaaaaaaaaaaaegbobaaaadaaaaaadiaaaaai
pccabaaaacaaaaaaegaobaaaaaaaaaaaegiocaaaaaaaaaaaadaaaaaadoaaaaab
"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
ConstBuffer "$Globals" 192
Vector 16 [_LightColor0]
Vector 48 [_Color]
Float 144 [_LightingBlend]
Vector 160 [_MainTex_ST]
Vector 176 [_SecondTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
BindCB  "UnityPerFrame" 2
"vs_4_0_level_9_1
eefiecedgbmkbhmhaioajgiabnhnejeocofkbmhoabaaaaaaceafaaaaaeaaaaaa
daaaaaaanaabaaaabaaeaaaajiaeaaaaebgpgodjjiabaaaajiabaaaaaaacpopp
deabaaaageaaaaaaafaaceaaaaaagaaaaaaagaaaaaaaceaaabaagaaaaaaaabaa
abaaabaaaaaaaaaaaaaaadaaabaaacaaaaaaaaaaaaaaajaaadaaadaaaaaaaaaa
abaaaaaaaeaaagaaaaaaaaaaacaaaeaaabaaakaaaaaaaaaaaaaaaaaaaaacpopp
fbaaaaafalaaapkaaaaaaaeaaaaaaaaaaaaaaaaaaaaaaaaabpaaaaacafaaaaia
aaaaapjabpaaaaacafaaabiaabaaapjabpaaaaacafaaaciaacaaapjabpaaaaac
afaaadiaadaaapjaaeaaaaaeaaaaadoaabaaoejaaeaaoekaaeaaookaaeaaaaae
aaaaamoaacaabejaafaabekaafaalekaabaaaaacaaaaapiaakaaoekaabaaaaac
abaaabiaalaaaakaaeaaaaaeaaaaapiaaaaaoeiaabaaaaiaabaaoekabcaaaaae
abaaapiaadaaaakaaaaaoeiaadaaoejaafaaaaadabaaapoaabaaoeiaacaaoeka
afaaaaadaaaaapiaaaaaffjaahaaoekaaeaaaaaeaaaaapiaagaaoekaaaaaaaja
aaaaoeiaaeaaaaaeaaaaapiaaiaaoekaaaaakkjaaaaaoeiaaeaaaaaeaaaaapia
ajaaoekaaaaappjaaaaaoeiaaeaaaaaeaaaaadmaaaaappiaaaaaoekaaaaaoeia
abaaaaacaaaaammaaaaaoeiappppaaaafdeieefcdiacaaaaeaaaabaaioaaaaaa
fjaaaaaeegiocaaaaaaaaaaaamaaaaaafjaaaaaeegiocaaaabaaaaaaaeaaaaaa
fjaaaaaeegiocaaaacaaaaaaafaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaad
dcbabaaaabaaaaaafpaaaaaddcbabaaaacaaaaaafpaaaaadpcbabaaaadaaaaaa
ghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaaabaaaaaagfaaaaad
mccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaacabaaaaaadiaaaaai
pcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaabaaaaaaabaaaaaadcaaaaak
pcaabaaaaaaaaaaaegiocaaaabaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaa
aaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaacaaaaaakgbkbaaa
aaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaabaaaaaa
adaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaaldccabaaaabaaaaaa
egbabaaaabaaaaaaegiacaaaaaaaaaaaakaaaaaaogikcaaaaaaaaaaaakaaaaaa
dcaaaaalmccabaaaabaaaaaaagbebaaaacaaaaaaagiecaaaaaaaaaaaalaaaaaa
kgiocaaaaaaaaaaaalaaaaaadcaaaaaopcaabaaaaaaaaaaaegiocaaaacaaaaaa
aeaaaaaaaceaaaaaaaaaaaeaaaaaaaeaaaaaaaeaaaaaaaeaegiocaaaaaaaaaaa
abaaaaaaaaaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaiaebaaaaaa
adaaaaaadcaaaaakpcaabaaaaaaaaaaaagiacaaaaaaaaaaaajaaaaaaegaobaaa
aaaaaaaaegbobaaaadaaaaaadiaaaaaipccabaaaacaaaaaaegaobaaaaaaaaaaa
egiocaaaaaaaaaaaadaaaaaadoaaaaabejfdeheoiaaaaaaaaeaaaaaaaiaaaaaa
giaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaahbaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaabaaaaaaadadaaaahbaaaaaaabaaaaaaaaaaaaaaadaaaaaa
acaaaaaaadadaaaahkaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaapapaaaa
faepfdejfeejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheoieaaaaaa
aeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaa
heaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaa
aaaaaaaaadaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
acaaaaaaapaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepem
epfcaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Vector 0 [_Color]
Vector 1 [_SecondTint]
Float 2 [_BlendIntensity]
Vector 3 [_DarkColor]
Float 4 [_Desaturate]
Float 5 [_Contrast]
Float 6 [_Intensity]
Vector 7 [_AvgLum]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 18 ALU, 2 TEX
PARAM c[9] = { program.local[0..7],
		{ 0.30004883, 0.58984375, 0.10998535, 0.15002441 } };
TEMP R0;
TEMP R1;
TEMP R2;
TEMP R3;
TEX R1, fragment.texcoord[1], texture[1], 2D;
TEX R0, fragment.texcoord[0], texture[0], 2D;
MUL R1, R1, c[1];
MUL R3, R1, c[2].x;
MAD R1, R3, R0, -R0;
MAD R0, R3.w, R1, R0;
MOV R2, c[3];
ADD R1, -R2, c[0];
DP3 R2.x, R0, c[8];
MAD R1, R2.x, R1, c[3];
ADD R1, R1, -R0;
MAD R0, R1, c[4].x, R0;
ADD R1, -R0, c[7];
MAD R0, R1, c[5].x, R0;
ADD R1, R0, c[8].w;
MUL R1, R1, fragment.color.primary;
MIN R0, R1, R0;
MUL result.color, R0, c[6].x;
END
# 18 instructions, 4 R-regs
"
}
SubProgram "d3d9 " {
Vector 0 [_Color]
Vector 1 [_SecondTint]
Float 2 [_BlendIntensity]
Vector 3 [_DarkColor]
Float 4 [_Desaturate]
Float 5 [_Contrast]
Float 6 [_Intensity]
Vector 7 [_AvgLum]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
"ps_2_0
; 17 ALU, 2 TEX
dcl_2d s0
dcl_2d s1
def c8, 0.30004883, 0.58984375, 0.10998535, 0.15002441
dcl t0.xy
dcl t1.xy
dcl v0
texld r1, t1, s1
texld r0, t0, s0
mul r1, r1, c1
mul r3, r1, c2.x
mad_pp r1, r3, r0, -r0
mad_pp r0, r3.w, r1, r0
mov_pp r2, c0
add_pp r1, -c3, r2
dp3_pp r2.x, r0, c8
mad_pp r1, r2.x, r1, c3
add_pp r1, r1, -r0
mad_pp r0, r1, c4.x, r0
add_pp r1, -r0, c7
mad_pp r0, r1, c5.x, r0
add_pp r1, r0, c8.w
mul_pp r1, r1, v0
min_pp r0, r1, r0
mul r0, r0, c6.x
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
ConstBuffer "$Globals" 192
Vector 48 [_Color]
Vector 64 [_SecondTint]
Float 80 [_BlendIntensity]
Vector 96 [_DarkColor]
Float 112 [_Desaturate]
Float 116 [_Contrast]
Float 120 [_Intensity]
Vector 128 [_AvgLum]
BindCB  "$Globals" 0
"ps_4_0
eefiecedppbjjhiohiecjccflodhldgnjjjgpepkabaaaaaaoaadaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcomacaaaaeaaaaaaallaaaaaafjaaaaae
egiocaaaaaaaaaaaajaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaa
abaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaa
ffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaadmcbabaaaabaaaaaagcbaaaad
pcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacadaaaaaaefaaaaaj
pcaabaaaaaaaaaaaogbkbaaaabaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaa
diaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaaegiocaaaaaaaaaaaaeaaaaaa
diaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaaagiacaaaaaaaaaaaafaaaaaa
efaaaaajpcaabaaaabaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaa
aaaaaaaadcaaaaakpcaabaaaacaaaaaaegaobaaaabaaaaaaegaobaaaaaaaaaaa
egaobaiaebaaaaaaabaaaaaadcaaaaajpcaabaaaaaaaaaaapgapbaaaaaaaaaaa
egaobaaaacaaaaaaegaobaaaabaaaaaabaaaaaakbcaabaaaabaaaaaaaceaaaaa
jkjjjjdodnakbhdpkoehobdnaaaaaaaaegacbaaaaaaaaaaaaaaaaaakpcaabaaa
acaaaaaaegiocaaaaaaaaaaaadaaaaaaegiocaiaebaaaaaaaaaaaaaaagaaaaaa
dcaaaaakpcaabaaaabaaaaaaagaabaaaabaaaaaaegaobaaaacaaaaaaegiocaaa
aaaaaaaaagaaaaaaaaaaaaaipcaabaaaabaaaaaaegaobaiaebaaaaaaaaaaaaaa
egaobaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaagiacaaaaaaaaaaaahaaaaaa
egaobaaaabaaaaaaegaobaaaaaaaaaaaaaaaaaajpcaabaaaabaaaaaaegaobaia
ebaaaaaaaaaaaaaaegiocaaaaaaaaaaaaiaaaaaadcaaaaakpcaabaaaaaaaaaaa
fgifcaaaaaaaaaaaahaaaaaaegaobaaaabaaaaaaegaobaaaaaaaaaaaaaaaaaak
pcaabaaaabaaaaaaegaobaaaaaaaaaaaaceaaaaajkjjbjdojkjjbjdojkjjbjdo
jkjjbjdodiaaaaahpcaabaaaabaaaaaaegaobaaaabaaaaaaegbobaaaacaaaaaa
ddaaaaahpcaabaaaaaaaaaaaegaobaaaaaaaaaaaegaobaaaabaaaaaadiaaaaai
pccabaaaaaaaaaaaegaobaaaaaaaaaaakgikcaaaaaaaaaaaahaaaaaadoaaaaab
"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
ConstBuffer "$Globals" 192
Vector 48 [_Color]
Vector 64 [_SecondTint]
Float 80 [_BlendIntensity]
Vector 96 [_DarkColor]
Float 112 [_Desaturate]
Float 116 [_Contrast]
Float 120 [_Intensity]
Vector 128 [_AvgLum]
BindCB  "$Globals" 0
"ps_4_0_level_9_1
eefiecedfpkddbafdgdajlneccibomgdbfdiiccpabaaaaaakmafaaaaaeaaaaaa
daaaaaaapiabaaaaomaeaaaahiafaaaaebgpgodjmaabaaaamaabaaaaaaacpppp
iiabaaaadiaaaaaaabaacmaaaaaadiaaaaaadiaaacaaceaaaaaadiaaaaaaaaaa
abababaaaaaaadaaagaaaaaaaaaaaaaaaaacppppfbaaaaafagaaapkajkjjjjdo
dnakbhdpkoehobdnjkjjbjdobpaaaaacaaaaaaiaaaaaaplabpaaaaacaaaaaaia
abaacplabpaaaaacaaaaaajaaaaiapkabpaaaaacaaaaaajaabaiapkaabaaaaac
aaaaadiaaaaabllaecaaaaadaaaaapiaaaaaoeiaabaioekaecaaaaadabaacpia
aaaaoelaaaaioekaafaaaaadaaaaapiaaaaaoeiaabaaoekaafaaaaadaaaacpia
aaaaoeiaacaaaakaaeaaaaaeacaacpiaabaaoeiaaaaaoeiaabaaoeibaeaaaaae
aaaacpiaaaaappiaacaaoeiaabaaoeiaaiaaaaadabaacbiaagaaoekaaaaaoeia
abaaaaacacaaapiaadaaoekaacaaaaadacaacpiaacaaoeibaaaaoekaaeaaaaae
abaacpiaabaaaaiaacaaoeiaadaaoekabcaaaaaeacaacpiaaeaaaakaabaaoeia
aaaaoeiaacaaaaadaaaaapiaacaaoeibafaaoekaaeaaaaaeaaaacpiaaeaaffka
aaaaoeiaacaaoeiaacaaaaadabaacpiaaaaaoeiaagaappkaafaaaaadabaacpia
abaaoeiaabaaoelaakaaaaadacaaapiaaaaaoeiaabaaoeiaafaaaaadaaaacpia
acaaoeiaaeaakkkaabaaaaacaaaicpiaaaaaoeiappppaaaafdeieefcomacaaaa
eaaaaaaallaaaaaafjaaaaaeegiocaaaaaaaaaaaajaaaaaafkaaaaadaagabaaa
aaaaaaaafkaaaaadaagabaaaabaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaa
fibiaaaeaahabaaaabaaaaaaffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaad
mcbabaaaabaaaaaagcbaaaadpcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaa
giaaaaacadaaaaaaefaaaaajpcaabaaaaaaaaaaaogbkbaaaabaaaaaaeghobaaa
abaaaaaaaagabaaaabaaaaaadiaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaa
egiocaaaaaaaaaaaaeaaaaaadiaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaa
agiacaaaaaaaaaaaafaaaaaaefaaaaajpcaabaaaabaaaaaaegbabaaaabaaaaaa
eghobaaaaaaaaaaaaagabaaaaaaaaaaadcaaaaakpcaabaaaacaaaaaaegaobaaa
abaaaaaaegaobaaaaaaaaaaaegaobaiaebaaaaaaabaaaaaadcaaaaajpcaabaaa
aaaaaaaapgapbaaaaaaaaaaaegaobaaaacaaaaaaegaobaaaabaaaaaabaaaaaak
bcaabaaaabaaaaaaaceaaaaajkjjjjdodnakbhdpkoehobdnaaaaaaaaegacbaaa
aaaaaaaaaaaaaaakpcaabaaaacaaaaaaegiocaaaaaaaaaaaadaaaaaaegiocaia
ebaaaaaaaaaaaaaaagaaaaaadcaaaaakpcaabaaaabaaaaaaagaabaaaabaaaaaa
egaobaaaacaaaaaaegiocaaaaaaaaaaaagaaaaaaaaaaaaaipcaabaaaabaaaaaa
egaobaiaebaaaaaaaaaaaaaaegaobaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaa
agiacaaaaaaaaaaaahaaaaaaegaobaaaabaaaaaaegaobaaaaaaaaaaaaaaaaaaj
pcaabaaaabaaaaaaegaobaiaebaaaaaaaaaaaaaaegiocaaaaaaaaaaaaiaaaaaa
dcaaaaakpcaabaaaaaaaaaaafgifcaaaaaaaaaaaahaaaaaaegaobaaaabaaaaaa
egaobaaaaaaaaaaaaaaaaaakpcaabaaaabaaaaaaegaobaaaaaaaaaaaaceaaaaa
jkjjbjdojkjjbjdojkjjbjdojkjjbjdodiaaaaahpcaabaaaabaaaaaaegaobaaa
abaaaaaaegbobaaaacaaaaaaddaaaaahpcaabaaaaaaaaaaaegaobaaaaaaaaaaa
egaobaaaabaaaaaadiaaaaaipccabaaaaaaaaaaaegaobaaaaaaaaaaakgikcaaa
aaaaaaaaahaaaaaadoaaaaabejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklkl"
}
}
 }
}
Fallback "Diffuse"
}