Shader "Custom/Selection/Highlight" {
Properties {
 _Color ("Base Color", Color) = (0.5,0.5,0.5,1)
 _HiColor ("Hot Color", Color) = (0.5,0.5,0.5,1)
 _Colorize ("Colorize", Color) = (1,1,1,1)
 _ColorIntensity ("Color Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _MoteTex ("Mote Texture", 2D) = "white" {}
 _MoteIntensity ("Mote Intensity", Float) = 1
 _VmoteSpeed ("Mote V Speed", Float) = 1
 _UmoteScale ("Mote U Scale", Float) = 1
 _VmoteScale ("Mote V Scale", Float) = 1
 _FlareTex ("Flare Texture", 2D) = "white" {}
 _FlareIntensity ("Flare Intensity", Float) = 1
 _VflareSpeed ("Flare V Speed", Float) = 1
 _UflareScale ("Flare U Scale", Float) = 1
 _VflareScale ("Flare V Scale", Float) = 1
 _MainTex ("Main Texture", 2D) = "black" {}
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend SrcAlpha OneMinusSrcAlpha
  ColorMask RGB
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
Float 5 [_Seed]
Vector 6 [_MainTex_ST]
"!!ARBvp1.0
# 9 ALU
PARAM c[7] = { program.local[0],
		state.matrix.mvp,
		program.local[5..6] };
TEMP R0;
MOV R0.y, vertex.texcoord[1];
ADD R0.x, vertex.texcoord[1], c[5];
MOV result.color, vertex.color;
MAD result.texcoord[0].xy, vertex.texcoord[0], c[6], c[6].zwzw;
MAD result.texcoord[1].xy, R0, c[6], c[6].zwzw;
DP4 result.position.w, vertex.position, c[4];
DP4 result.position.z, vertex.position, c[3];
DP4 result.position.y, vertex.position, c[2];
DP4 result.position.x, vertex.position, c[1];
END
# 9 instructions, 1 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
Matrix 0 [glstate_matrix_mvp]
Float 4 [_Seed]
Vector 5 [_MainTex_ST]
"vs_2_0
; 9 ALU
dcl_position0 v0
dcl_texcoord0 v1
dcl_texcoord1 v2
dcl_color0 v3
mov r0.y, v2
add r0.x, v2, c4
mov oD0, v3
mad oT0.xy, v1, c5, c5.zwzw
mad oT1.xy, r0, c5, c5.zwzw
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
ConstBuffer "$Globals" 128
Float 104 [_Seed]
Vector 112 [_MainTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
"vs_4_0
eefiecedklpiadpmdajdafjamcaljaamedfmllloabaaaaaabiadaaaaadaaaaaa
cmaaaaaaleaaaaaaeaabaaaaejfdeheoiaaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaahbaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaahbaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaa
adadaaaahkaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaapapaaaafaepfdej
feejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheoieaaaaaaaeaaaaaa
aiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaaaaaaaaaa
adaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaakl
fdeieefcnaabaaaaeaaaabaaheaaaaaafjaaaaaeegiocaaaaaaaaaaaaiaaaaaa
fjaaaaaeegiocaaaabaaaaaaaeaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaad
dcbabaaaabaaaaaafpaaaaaddcbabaaaacaaaaaafpaaaaadpcbabaaaadaaaaaa
ghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaaabaaaaaagfaaaaad
mccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaacabaaaaaadiaaaaai
pcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaabaaaaaaabaaaaaadcaaaaak
pcaabaaaaaaaaaaaegiocaaaabaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaa
aaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaacaaaaaakgbkbaaa
aaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaabaaaaaa
adaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaaaaaaaaaiecaabaaaaaaaaaaa
akbabaaaacaaaaaackiacaaaaaaaaaaaagaaaaaadgaaaaaficaabaaaaaaaaaaa
bkbabaaaacaaaaaadcaaaaalmccabaaaabaaaaaakgaobaaaaaaaaaaaagiecaaa
aaaaaaaaahaaaaaakgiocaaaaaaaaaaaahaaaaaadcaaaaaldccabaaaabaaaaaa
egbabaaaabaaaaaaegiacaaaaaaaaaaaahaaaaaaogikcaaaaaaaaaaaahaaaaaa
dgaaaaafpccabaaaacaaaaaaegbobaaaadaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
ConstBuffer "$Globals" 128
Float 104 [_Seed]
Vector 112 [_MainTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
"vs_4_0_level_9_1
eefieceddackjhnkihjcgmjgkfopfglpmhcmlbijabaaaaaafiaeaaaaaeaaaaaa
daaaaaaagmabaaaaeeadaaaammadaaaaebgpgodjdeabaaaadeabaaaaaaacpopp
peaaaaaaeaaaaaaaacaaceaaaaaadmaaaaaadmaaaaaaceaaabaadmaaaaaaagaa
acaaabaaaaaaaaaaabaaaaaaaeaaadaaaaaaaaaaaaaaaaaaaaacpoppbpaaaaac
afaaaaiaaaaaapjabpaaaaacafaaabiaabaaapjabpaaaaacafaaaciaacaaapja
bpaaaaacafaaadiaadaaapjaaeaaaaaeaaaaadoaabaaoejaacaaoekaacaaooka
acaaaaadaaaaaiiaacaaaajaabaakkkaabaaaaacaaaaaeiaacaaffjaaeaaaaae
aaaaamoaaaaaoeiaacaabekaacaalekaafaaaaadaaaaapiaaaaaffjaaeaaoeka
aeaaaaaeaaaaapiaadaaoekaaaaaaajaaaaaoeiaaeaaaaaeaaaaapiaafaaoeka
aaaakkjaaaaaoeiaaeaaaaaeaaaaapiaagaaoekaaaaappjaaaaaoeiaaeaaaaae
aaaaadmaaaaappiaaaaaoekaaaaaoeiaabaaaaacaaaaammaaaaaoeiaabaaaaac
abaaapoaadaaoejappppaaaafdeieefcnaabaaaaeaaaabaaheaaaaaafjaaaaae
egiocaaaaaaaaaaaaiaaaaaafjaaaaaeegiocaaaabaaaaaaaeaaaaaafpaaaaad
pcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaaddcbabaaaacaaaaaa
fpaaaaadpcbabaaaadaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaad
dccabaaaabaaaaaagfaaaaadmccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaa
giaaaaacabaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaa
abaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaaaaaaaaa
agbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaa
abaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaa
aaaaaaaaegiocaaaabaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaa
aaaaaaaiecaabaaaaaaaaaaaakbabaaaacaaaaaackiacaaaaaaaaaaaagaaaaaa
dgaaaaaficaabaaaaaaaaaaabkbabaaaacaaaaaadcaaaaalmccabaaaabaaaaaa
kgaobaaaaaaaaaaaagiecaaaaaaaaaaaahaaaaaakgiocaaaaaaaaaaaahaaaaaa
dcaaaaaldccabaaaabaaaaaaegbabaaaabaaaaaaegiacaaaaaaaaaaaahaaaaaa
ogikcaaaaaaaaaaaahaaaaaadgaaaaafpccabaaaacaaaaaaegbobaaaadaaaaaa
doaaaaabejfdeheoiaaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaaaaaaaaaapapaaaahbaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaa
adadaaaahbaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaaadadaaaahkaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaadaaaaaaapapaaaafaepfdejfeejepeoaafeeffi
edepepfceeaaedepemepfcaaepfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapaaaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Vector 0 [_Time]
Vector 1 [_Color]
Vector 2 [_Colorize]
Vector 3 [_HiColor]
Float 4 [_ColorIntensity]
Float 5 [_Intensity]
Float 6 [_FlareIntensity]
Float 7 [_MoteIntensity]
Float 8 [_VmoteSpeed]
Float 9 [_UmoteScale]
Float 10 [_VmoteScale]
Float 11 [_VflareSpeed]
Float 12 [_UflareScale]
Float 13 [_VflareScale]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FlareTex] 2D 1
SetTexture 2 [_MoteTex] 2D 2
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 31 ALU, 3 TEX
PARAM c[15] = { program.local[0..13],
		{ 0.5, 0.050000001 } };
TEMP R0;
TEMP R1;
TEX R0.x, fragment.texcoord[0], texture[0], 2D;
MOV R0.y, c[8].x;
MUL R0.y, R0, c[0].x;
FRC R0.z, R0.y;
MUL R0.y, R0.x, c[5].x;
MOV R0.x, c[14].y;
MUL R0.x, R0, c[0];
MAD R0.w, R0.y, c[10].x, R0.z;
MOV R1.x, c[11];
MUL R0.z, R1.x, c[0].x;
FRC R0.z, R0;
MAD R1.y, R0, c[13].x, R0.z;
FRC R0.x, R0;
MAD R1.x, fragment.texcoord[1], c[12], R0;
MUL R0.z, fragment.texcoord[1].x, c[9].x;
TEX R0.x, R1, texture[1], 2D;
TEX R1.xyz, R0.zwzw, texture[2], 2D;
MUL R0.x, R0, c[6];
MUL R1.xyz, R1, fragment.color.primary.x;
MUL R0.w, R0.y, R0.x;
MAD_SAT R1.xyz, R1, c[14].x, R0.y;
ADD R1.xyz, R1, R0.w;
MUL R1.xyz, R1, c[7].x;
MUL R0.xyz, R1, R0.y;
MUL R0.xyz, R0, fragment.color.primary.x;
MAD R1.xyz, R0, c[3], R0.w;
ADD R1.xyz, R1, -c[1];
MAD R1.xyz, R0, R1, c[1];
MUL R1.xyz, R1, c[4].x;
MOV R1.w, R0.x;
MUL result.color, R1, c[2];
END
# 31 instructions, 2 R-regs
"
}
SubProgram "d3d9 " {
Vector 0 [_Time]
Vector 1 [_Color]
Vector 2 [_Colorize]
Vector 3 [_HiColor]
Float 4 [_ColorIntensity]
Float 5 [_Intensity]
Float 6 [_FlareIntensity]
Float 7 [_MoteIntensity]
Float 8 [_VmoteSpeed]
Float 9 [_UmoteScale]
Float 10 [_VmoteScale]
Float 11 [_VflareSpeed]
Float 12 [_UflareScale]
Float 13 [_VflareScale]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FlareTex] 2D 1
SetTexture 2 [_MoteTex] 2D 2
"ps_2_0
; 29 ALU, 3 TEX
dcl_2d s0
dcl_2d s1
dcl_2d s2
def c14, 0.05000000, 0.50000000, 0, 0
dcl t0.xy
dcl t1.x
dcl v0.x
texld r0, t0, s0
mov r1.x, c0
mul r1.x, c8, r1
frc r2.x, r1
mul r0.x, r0, c5
mad r2.y, r0.x, c10.x, r2.x
mov r1.x, c0
mul r2.x, c11, r1
frc r2.x, r2
mad r1.y, r0.x, c13.x, r2.x
mov r1.x, c0
mul r1.x, c14, r1
frc r1.x, r1
mul r2.x, t1, c9
mad r1.x, t1, c12, r1
texld r1, r1, s1
texld r2, r2, s2
mul r1.x, r1, c6
mul r2.xyz, r2, v0.x
mul r1.x, r0, r1
mad_sat r2.xyz, r2, c14.y, r0.x
add r2.xyz, r2, r1.x
mul r2.xyz, r2, c7.x
mul r0.xyz, r2, r0.x
mul r0.xyz, r0, v0.x
mad_pp r1.xyz, r0, c3, r1.x
add_pp r1.xyz, r1, -c1
mad_pp r1.xyz, r0, r1, c1
mul_pp r1.xyz, r1, c4.x
mov_pp r1.w, r0.x
mul_pp r0, r1, c2
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FlareTex] 2D 2
SetTexture 2 [_MoteTex] 2D 1
ConstBuffer "$Globals" 128
Vector 16 [_Color]
Vector 32 [_Colorize]
Vector 48 [_HiColor]
Float 64 [_ColorIntensity]
Float 68 [_Intensity]
Float 72 [_FlareIntensity]
Float 76 [_MoteIntensity]
Float 80 [_VmoteSpeed]
Float 84 [_UmoteScale]
Float 88 [_VmoteScale]
Float 92 [_VflareSpeed]
Float 96 [_UflareScale]
Float 100 [_VflareScale]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
"ps_4_0
eefiecedhdckilaemdembemhemdefedjfhlfoeklabaaaaaaniaeaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amaeaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapabaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcoeadaaaaeaaaaaaapjaaaaaafjaaaaae
egiocaaaaaaaaaaaahaaaaaafjaaaaaeegiocaaaabaaaaaaabaaaaaafkaaaaad
aagabaaaaaaaaaaafkaaaaadaagabaaaabaaaaaafkaaaaadaagabaaaacaaaaaa
fibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaaffffaaaa
fibiaaaeaahabaaaacaaaaaaffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaad
ecbabaaaabaaaaaagcbaaaadbcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaa
giaaaaacadaaaaaadiaaaaaibcaabaaaaaaaaaaackbabaaaabaaaaaabkiacaaa
aaaaaaaaafaaaaaadiaaaaajmcaabaaaaaaaaaaapgidcaaaaaaaaaaaafaaaaaa
agiacaaaabaaaaaaaaaaaaaabkaaaaafmcaabaaaaaaaaaaakgaobaaaaaaaaaaa
efaaaaajpcaabaaaabaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaa
aaaaaaaadiaaaaaibcaabaaaabaaaaaaakaabaaaabaaaaaabkiacaaaaaaaaaaa
aeaaaaaadcaaaaakccaabaaaaaaaaaaaakaabaaaabaaaaaackiacaaaaaaaaaaa
afaaaaaadkaabaaaaaaaaaaadcaaaaakccaabaaaacaaaaaaakaabaaaabaaaaaa
bkiacaaaaaaaaaaaagaaaaaackaabaaaaaaaaaaaefaaaaajpcaabaaaaaaaaaaa
egaabaaaaaaaaaaaeghobaaaacaaaaaaaagabaaaabaaaaaadiaaaaahhcaabaaa
aaaaaaaaegacbaaaaaaaaaaaagbabaaaacaaaaaadccaaaamhcaabaaaaaaaaaaa
egacbaaaaaaaaaaaaceaaaaaaaaaaadpaaaaaadpaaaaaadpaaaaaaaaagaabaaa
abaaaaaadiaaaaaiicaabaaaaaaaaaaaakiacaaaabaaaaaaaaaaaaaaabeaaaaa
mnmmemdnbkaaaaaficaabaaaaaaaaaaadkaabaaaaaaaaaaadcaaaaakbcaabaaa
acaaaaaackbabaaaabaaaaaaakiacaaaaaaaaaaaagaaaaaadkaabaaaaaaaaaaa
efaaaaajpcaabaaaacaaaaaaegaabaaaacaaaaaaeghobaaaabaaaaaaaagabaaa
acaaaaaadiaaaaaiicaabaaaaaaaaaaaakaabaaaacaaaaaackiacaaaaaaaaaaa
aeaaaaaadcaaaaajhcaabaaaaaaaaaaapgapbaaaaaaaaaaaagaabaaaabaaaaaa
egacbaaaaaaaaaaadiaaaaaihcaabaaaaaaaaaaaegacbaaaaaaaaaaapgipcaaa
aaaaaaaaaeaaaaaadiaaaaahpcaabaaaaaaaaaaaagaabaaaabaaaaaaegaobaaa
aaaaaaaadiaaaaahlcaabaaaabaaaaaajgabbaaaaaaaaaaaagbabaaaacaaaaaa
dcaaaaakhcaabaaaaaaaaaaaegiccaaaaaaaaaaaadaaaaaadganbaaaabaaaaaa
pgapbaaaaaaaaaaaaaaaaaajhcaabaaaaaaaaaaaegacbaaaaaaaaaaaegiccaia
ebaaaaaaaaaaaaaaabaaaaaadcaaaaakhcaabaaaaaaaaaaadganbaaaabaaaaaa
egacbaaaaaaaaaaaegiccaaaaaaaaaaaabaaaaaadiaaaaaihcaabaaaabaaaaaa
egacbaaaaaaaaaaaagiacaaaaaaaaaaaaeaaaaaadiaaaaaipccabaaaaaaaaaaa
egaobaaaabaaaaaaegiocaaaaaaaaaaaacaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FlareTex] 2D 2
SetTexture 2 [_MoteTex] 2D 1
ConstBuffer "$Globals" 128
Vector 16 [_Color]
Vector 32 [_Colorize]
Vector 48 [_HiColor]
Float 64 [_ColorIntensity]
Float 68 [_Intensity]
Float 72 [_FlareIntensity]
Float 76 [_MoteIntensity]
Float 80 [_VmoteSpeed]
Float 84 [_UmoteScale]
Float 88 [_VmoteScale]
Float 92 [_VflareSpeed]
Float 96 [_UflareScale]
Float 100 [_VflareScale]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
"ps_4_0_level_9_1
eefiecedapbjfnefgpihgholpaambnflkcofmbjnabaaaaaagiahaaaaaeaaaaaa
daaaaaaalmacaaaakiagaaaadeahaaaaebgpgodjieacaaaaieacaaaaaaacpppp
dmacaaaaeiaaaaaaacaadaaaaaaaeiaaaaaaeiaaadaaceaaaaaaeiaaaaaaaaaa
acababaaabacacaaaaaaabaaagaaaaaaaaaaaaaaabaaaaaaabaaagaaaaaaaaaa
aaacppppfbaaaaafahaaapkamnmmemdnaaaaaadpaaaaaaaaaaaaaaaabpaaaaac
aaaaaaiaaaaaaplabpaaaaacaaaaaaiaabaaaplabpaaaaacaaaaaajaaaaiapka
bpaaaaacaaaaaajaabaiapkabpaaaaacaaaaaajaacaiapkaecaaaaadaaaaapia
aaaaoelaaaaioekaafaaaaadabaaabiaaaaapplaaeaaffkaabaaaaacacaaajia
aeaaoekaafaaaaadaaaaaciaacaaaaiaagaaaakabdaaaaacaaaaaciaaaaaffia
afaaaaadaaaaabiaaaaaaaiaadaaffkaaeaaaaaeabaaaciaaaaaaaiaaeaakkka
aaaaffiaabaaaaacacaaabiaahaaaakaafaaaaadaaaaaciaacaaaaiaagaaaaka
bdaaaaacaaaaaciaaaaaffiaaeaaaaaeacaaabiaaaaapplaafaaaakaaaaaffia
afaaaaadaaaaaciaacaappiaagaaaakabdaaaaacaaaaaciaaaaaffiaaeaaaaae
acaaaciaaaaaaaiaafaaffkaaaaaffiaecaaaaadabaaapiaabaaoeiaabaioeka
ecaaaaadacaaapiaacaaoeiaacaioekaafaaaaadaaaaaoiaabaabliaabaaaala
aeaaaaaeaaaaboiaaaaaoeiaahaaffkaaaaaaaiaafaaaaadabaaabiaacaaaaia
adaakkkaaeaaaaaeaaaaaoiaabaaaaiaaaaaaaiaaaaaoeiaafaaaaadabaacbia
aaaaaaiaabaaaaiaafaaaaadaaaaaoiaaaaaoeiaadaappkaafaaaaadaaaaahia
aaaaaaiaaaaabliaafaaaaadaaaachiaaaaaoeiaabaaaalaaeaaaaaeabaachia
acaaoekaaaaaoeiaabaaaaiabcaaaaaeacaachiaaaaaoeiaabaaoeiaaaaaoeka
abaaaaacaaaaciiaaaaaaaiaafaaaaadaaaachiaacaaoeiaadaaaakaafaaaaad
aaaacpiaaaaaoeiaabaaoekaabaaaaacaaaicpiaaaaaoeiappppaaaafdeieefc
oeadaaaaeaaaaaaapjaaaaaafjaaaaaeegiocaaaaaaaaaaaahaaaaaafjaaaaae
egiocaaaabaaaaaaabaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaa
abaaaaaafkaaaaadaagabaaaacaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaa
fibiaaaeaahabaaaabaaaaaaffffaaaafibiaaaeaahabaaaacaaaaaaffffaaaa
gcbaaaaddcbabaaaabaaaaaagcbaaaadecbabaaaabaaaaaagcbaaaadbcbabaaa
acaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacadaaaaaadiaaaaaibcaabaaa
aaaaaaaackbabaaaabaaaaaabkiacaaaaaaaaaaaafaaaaaadiaaaaajmcaabaaa
aaaaaaaapgidcaaaaaaaaaaaafaaaaaaagiacaaaabaaaaaaaaaaaaaabkaaaaaf
mcaabaaaaaaaaaaakgaobaaaaaaaaaaaefaaaaajpcaabaaaabaaaaaaegbabaaa
abaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaadiaaaaaibcaabaaaabaaaaaa
akaabaaaabaaaaaabkiacaaaaaaaaaaaaeaaaaaadcaaaaakccaabaaaaaaaaaaa
akaabaaaabaaaaaackiacaaaaaaaaaaaafaaaaaadkaabaaaaaaaaaaadcaaaaak
ccaabaaaacaaaaaaakaabaaaabaaaaaabkiacaaaaaaaaaaaagaaaaaackaabaaa
aaaaaaaaefaaaaajpcaabaaaaaaaaaaaegaabaaaaaaaaaaaeghobaaaacaaaaaa
aagabaaaabaaaaaadiaaaaahhcaabaaaaaaaaaaaegacbaaaaaaaaaaaagbabaaa
acaaaaaadccaaaamhcaabaaaaaaaaaaaegacbaaaaaaaaaaaaceaaaaaaaaaaadp
aaaaaadpaaaaaadpaaaaaaaaagaabaaaabaaaaaadiaaaaaiicaabaaaaaaaaaaa
akiacaaaabaaaaaaaaaaaaaaabeaaaaamnmmemdnbkaaaaaficaabaaaaaaaaaaa
dkaabaaaaaaaaaaadcaaaaakbcaabaaaacaaaaaackbabaaaabaaaaaaakiacaaa
aaaaaaaaagaaaaaadkaabaaaaaaaaaaaefaaaaajpcaabaaaacaaaaaaegaabaaa
acaaaaaaeghobaaaabaaaaaaaagabaaaacaaaaaadiaaaaaiicaabaaaaaaaaaaa
akaabaaaacaaaaaackiacaaaaaaaaaaaaeaaaaaadcaaaaajhcaabaaaaaaaaaaa
pgapbaaaaaaaaaaaagaabaaaabaaaaaaegacbaaaaaaaaaaadiaaaaaihcaabaaa
aaaaaaaaegacbaaaaaaaaaaapgipcaaaaaaaaaaaaeaaaaaadiaaaaahpcaabaaa
aaaaaaaaagaabaaaabaaaaaaegaobaaaaaaaaaaadiaaaaahlcaabaaaabaaaaaa
jgabbaaaaaaaaaaaagbabaaaacaaaaaadcaaaaakhcaabaaaaaaaaaaaegiccaaa
aaaaaaaaadaaaaaadganbaaaabaaaaaapgapbaaaaaaaaaaaaaaaaaajhcaabaaa
aaaaaaaaegacbaaaaaaaaaaaegiccaiaebaaaaaaaaaaaaaaabaaaaaadcaaaaak
hcaabaaaaaaaaaaadganbaaaabaaaaaaegacbaaaaaaaaaaaegiccaaaaaaaaaaa
abaaaaaadiaaaaaihcaabaaaabaaaaaaegacbaaaaaaaaaaaagiacaaaaaaaaaaa
aeaaaaaadiaaaaaipccabaaaaaaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaa
acaaaaaadoaaaaabejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaa
abaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
abaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaaamaeaaaa
hnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapabaaaafdfgfpfagphdgjhe
gjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaaabaaaaaa
aiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaafdfgfpfe
gbhcghgfheaaklkl"
}
}
 }
}
Fallback Off
}