Shader "Custom/Card/MissingCardDesaturateAlpha" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondScaleUV ("Second UV Scale", Float) = 1
 _SecondIntensity ("SecondIntensity", Float) = 1
 _Color ("Color", Color) = (0.5,0.5,0.5,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
  BindChannels {
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog { Mode Off }
  Blend SrcAlpha OneMinusSrcAlpha
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform highp vec4 _MainTex_ST;
uniform mediump float _LightingBlend;
uniform mediump float _SecondScaleUV;
uniform lowp vec4 _LightColor0;
uniform highp vec4 glstate_lightmodel_ambient;
uniform highp mat4 glstate_matrix_mvp;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesColor;
attribute vec4 _glesVertex;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = mix (_glesColor, ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = (_glesVertex.xz * _SecondScaleUV);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform lowp vec4 _AvgLum;
uniform mediump float _Intensity;
uniform mediump float _Contrast;
uniform mediump float _Desaturate;
uniform lowp vec4 _Color;
uniform mediump float _SecondIntensity;
uniform sampler2D _SecondTex;
uniform sampler2D _MainTex;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_SecondTex, xlv_TEXCOORD1);
  mediump float tmpvar_5;
  tmpvar_5 = col_2.w;
  mediump float tmpvar_6;
  tmpvar_6 = dot (vec3(0.3, 0.59, 0.11), col_2.xyz);
  mediump vec4 tmpvar_7;
  tmpvar_7.x = tmpvar_6;
  tmpvar_7.y = tmpvar_6;
  tmpvar_7.z = tmpvar_6;
  tmpvar_7.w = col_2.w;
  col_2.xyz = mix (mix (col_2, tmpvar_7, vec4(_Desaturate)), _AvgLum, vec4(_Contrast)).xyz;
  col_2.w = (((1.0 - tmpvar_6) * tmpvar_5) * clamp ((tmpvar_4 * _SecondIntensity), 0.0, 1.0)).x;
  tmpvar_1 = (((col_2 * _Color) * _Intensity) * xlv_COLOR);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback Off
}