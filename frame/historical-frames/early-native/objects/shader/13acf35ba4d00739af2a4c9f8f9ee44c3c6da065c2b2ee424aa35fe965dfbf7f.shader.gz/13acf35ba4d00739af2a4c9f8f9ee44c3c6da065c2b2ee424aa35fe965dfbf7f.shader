Shader "Custom/Card/UnlitTextureReflection" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SpecTex ("Specular (RGB)", 2D) = "white" {}
 _ReflTex ("Reflection (RGB)", 2D) = "white" {}
 _ReflectionIntensity ("Reflection Intensity", Float) = 1
 _ReflectionColor ("Reflection Color", Color) = (0.8,0.8,0.8,1)
 _ReflectionFalloffColor ("Reflection Falloff Color", Color) = (0.3,0.3,0.3,1)
 _ReflectionFalloff ("Reflection Falloff", Float) = 2.5
 _ReflectionRotation ("Reflection Rotation", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="True" }
 Pass {
  Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="True" }
  BindChannels {
   Bind "color", Color
   Bind "normal", Normal
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
Matrix 5 [_Object2World]
Vector 2 [_Time]
Vector 3 [_WorldSpaceCameraPos]
Vector 4 [unity_Scale]
Vector 13 [_LightColor0]
Vector 14 [_ReflectionColor]
Vector 15 [_ReflectionFalloffColor]
Float 16 [_ReflectionFalloff]
Float 17 [_ReflectionRotation]
Float 18 [_LightingBlend]
Vector 19 [_MainTex_ST]
"!!ARBvp1.0
# 36 ALU
PARAM c[20] = { { 0.30000001, 2, 0.07 },
		state.lightmodel.ambient,
		program.local[2..8],
		state.matrix.mvp,
		program.local[13..19] };
TEMP R0;
TEMP R1;
TEMP R2;
TEMP R3;
MUL R3.xyz, vertex.normal, c[4].w;
DP4 R2.y, vertex.position, c[7];
DP4 R2.x, vertex.position, c[5];
DP3 R1.z, R3, c[7];
DP3 R1.x, R3, c[5];
DP3 R1.y, R3, c[6];
MUL R3.xyz, R1, c[0].x;
MOV R0.z, R2.y;
MOV R0.x, R2;
DP4 R0.y, vertex.position, c[6];
ADD R0.xyz, -R0, c[3];
DP3 R0.w, R0, R0;
RSQ R0.w, R0.w;
MUL R0.xyz, R0.w, R0;
DP3 R0.y, R0, R3;
ABS R1.x, R0.y;
MOV R0.x, c[0].y;
MUL R0, R0.x, c[1];
POW R2.z, R1.x, c[16].x;
ADD R1, R0, c[13];
MOV R0, c[15];
ADD R1, R1, -vertex.color;
ADD R0, -R0, c[14];
MAD R0, R2.z, R0, c[15];
MAD R1, R1, c[18].x, vertex.color;
MUL result.color, R0, R1;
MOV R0.z, c[17].x;
MAD R0.xy, vertex.texcoord[0], c[19], c[19].zwzw;
MUL R1.x, R0.z, c[2];
MAD R0.zw, R3.xyxz, -R0.x, R2.xyxy;
MAD result.texcoord[1].xy, R0.zwzw, c[0].z, R1.x;
MOV result.texcoord[0].xy, R0;
DP4 result.position.w, vertex.position, c[12];
DP4 result.position.z, vertex.position, c[11];
DP4 result.position.y, vertex.position, c[10];
DP4 result.position.x, vertex.position, c[9];
END
# 36 instructions, 4 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
Matrix 0 [glstate_matrix_mvp]
Matrix 4 [_Object2World]
Vector 8 [glstate_lightmodel_ambient]
Vector 9 [_Time]
Vector 10 [_WorldSpaceCameraPos]
Vector 11 [unity_Scale]
Vector 12 [_LightColor0]
Vector 13 [_ReflectionColor]
Vector 14 [_ReflectionFalloffColor]
Float 15 [_ReflectionFalloff]
Float 16 [_ReflectionRotation]
Float 17 [_LightingBlend]
Vector 18 [_MainTex_ST]
"vs_2_0
; 39 ALU
def c19, 0.30000001, 2.00000000, 0.07000000, 0
dcl_position0 v0
dcl_normal0 v1
dcl_texcoord0 v2
dcl_color0 v3
mul r3.xyz, v1, c11.w
dp4 r2.y, v0, c6
dp4 r2.x, v0, c4
dp3 r1.z, r3, c6
dp3 r1.x, r3, c4
dp3 r1.y, r3, c5
mul r3.xyz, r1, c19.x
mov r0.z, r2.y
mov r0.x, r2
dp4 r0.y, v0, c5
add r0.xyz, -r0, c10
dp3 r0.w, r0, r0
rsq r0.w, r0.w
mul r0.xyz, r0.w, r0
dp3 r0.x, r0, r3
abs r1.x, r0
pow r0, r1.x, c15.x
mov r2.z, r0.x
mov r1, c8
mul r1, c19.y, r1
add r1, r1, c12
mov r0, c13
add r1, r1, -v3
add r0, -c14, r0
mad r0, r2.z, r0, c14
mad r1, r1, c17.x, v3
mul oD0, r0, r1
mov r0.z, c9.x
mad r0.xy, v2, c18, c18.zwzw
mul r1.x, c16, r0.z
mad r0.zw, r3.xyxz, -r0.x, r2.xyxy
mad oT1.xy, r0.zwzw, c19.z, r1.x
mov oT0.xy, r0
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Vector 48 [_ReflectionColor]
Vector 64 [_ReflectionFalloffColor]
Float 84 [_ReflectionFalloff]
Float 88 [_ReflectionRotation]
Float 92 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
Vector 64 [_WorldSpaceCameraPos] 3
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
Matrix 192 [_Object2World]
Vector 320 [unity_Scale]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
BindCB  "UnityPerFrame" 3
"vs_4_0
eefiecedmokcjlnchooggikpjbbbaeekaecbapkkabaaaaaakiagaaaaadaaaaaa
cmaaaaaapeaaaaaaiaabaaaaejfdeheomaaaaaaaagaaaaaaaiaaaaaajiaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaakbaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaapaaaaaakjaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
ahahaaaalaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaapadaaaalaaaaaaa
abaaaaaaaaaaaaaaadaaaaaaaeaaaaaaapaaaaaaljaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaafaaaaaaapapaaaafaepfdejfeejepeoaafeebeoehefeofeaaeoepfc
enebemaafeeffiedepepfceeaaedepemepfcaaklepfdeheoieaaaaaaaeaaaaaa
aiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaabaaaaaaapaaaaaahkaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaacaaaaaaadamaaaahkaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaa
amadaaaafdfgfpfagphdgjhegjgpgoaaedepemepfcaafeeffiedepepfceeaakl
fdeieefccaafaaaaeaaaabaaeiabaaaafjaaaaaeegiocaaaaaaaaaaaahaaaaaa
fjaaaaaeegiocaaaabaaaaaaafaaaaaafjaaaaaeegiocaaaacaaaaaabfaaaaaa
fjaaaaaeegiocaaaadaaaaaaafaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaad
hcbabaaaacaaaaaafpaaaaaddcbabaaaadaaaaaafpaaaaadpcbabaaaafaaaaaa
ghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaadpccabaaaabaaaaaagfaaaaad
dccabaaaacaaaaaagfaaaaadmccabaaaacaaaaaagiaaaaacaeaaaaaadiaaaaai
pcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaacaaaaaaabaaaaaadcaaaaak
pcaabaaaaaaaaaaaegiocaaaacaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaa
aaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaacaaaaaaacaaaaaakgbkbaaa
aaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaacaaaaaa
adaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaadiaaaaaihcaabaaaaaaaaaaa
fgbfbaaaaaaaaaaaegiccaaaacaaaaaaanaaaaaadcaaaaakhcaabaaaaaaaaaaa
egiccaaaacaaaaaaamaaaaaaagbabaaaaaaaaaaaegacbaaaaaaaaaaadcaaaaak
hcaabaaaaaaaaaaaegiccaaaacaaaaaaaoaaaaaakgbkbaaaaaaaaaaaegacbaaa
aaaaaaaadcaaaaakhcaabaaaaaaaaaaaegiccaaaacaaaaaaapaaaaaapgbpbaaa
aaaaaaaaegacbaaaaaaaaaaaaaaaaaajhcaabaaaabaaaaaaegacbaiaebaaaaaa
aaaaaaaaegiccaaaabaaaaaaaeaaaaaabaaaaaahccaabaaaaaaaaaaaegacbaaa
abaaaaaaegacbaaaabaaaaaaeeaaaaafccaabaaaaaaaaaaabkaabaaaaaaaaaaa
diaaaaahhcaabaaaabaaaaaafgafbaaaaaaaaaaaegacbaaaabaaaaaadiaaaaai
hcaabaaaacaaaaaaegbcbaaaacaaaaaapgipcaaaacaaaaaabeaaaaaadiaaaaai
hcaabaaaadaaaaaafgafbaaaacaaaaaaegiccaaaacaaaaaaanaaaaaadcaaaaak
lcaabaaaacaaaaaaegiicaaaacaaaaaaamaaaaaaagaabaaaacaaaaaaegaibaaa
adaaaaaadcaaaaakhcaabaaaacaaaaaaegiccaaaacaaaaaaaoaaaaaakgakbaaa
acaaaaaaegadbaaaacaaaaaadiaaaaakhcaabaaaacaaaaaaegacbaaaacaaaaaa
aceaaaaajkjjjjdojkjjjjdojkjjjjdoaaaaaaaabaaaaaahccaabaaaaaaaaaaa
egacbaaaabaaaaaaegacbaaaacaaaaaacpaaaaagccaabaaaaaaaaaaabkaabaia
ibaaaaaaaaaaaaaadiaaaaaiccaabaaaaaaaaaaabkaabaaaaaaaaaaabkiacaaa
aaaaaaaaafaaaaaabjaaaaafccaabaaaaaaaaaaabkaabaaaaaaaaaaaaaaaaaak
pcaabaaaabaaaaaaegiocaaaaaaaaaaaadaaaaaaegiocaiaebaaaaaaaaaaaaaa
aeaaaaaadcaaaaakpcaabaaaabaaaaaafgafbaaaaaaaaaaaegaobaaaabaaaaaa
egiocaaaaaaaaaaaaeaaaaaadcaaaaaopcaabaaaadaaaaaaegiocaaaadaaaaaa
aeaaaaaaaceaaaaaaaaaaaeaaaaaaaeaaaaaaaeaaaaaaaeaegiocaaaaaaaaaaa
abaaaaaaaaaaaaaipcaabaaaadaaaaaaegaobaaaadaaaaaaegbobaiaebaaaaaa
afaaaaaadcaaaaakpcaabaaaadaaaaaapgipcaaaaaaaaaaaafaaaaaaegaobaaa
adaaaaaaegbobaaaafaaaaaadiaaaaahpccabaaaabaaaaaaegaobaaaabaaaaaa
egaobaaaadaaaaaadcaaaaalkcaabaaaaaaaaaaaagbebaaaadaaaaaaagiecaaa
aaaaaaaaagaaaaaakgiocaaaaaaaaaaaagaaaaaadcaaaaakfcaabaaaaaaaaaaa
fgafbaiaebaaaaaaaaaaaaaaagacbaaaacaaaaaaagacbaaaaaaaaaaadgaaaaaf
dccabaaaacaaaaaangafbaaaaaaaaaaadiaaaaajccaabaaaaaaaaaaackiacaaa
aaaaaaaaafaaaaaaakiacaaaabaaaaaaaaaaaaaadcaaaaammccabaaaacaaaaaa
agaibaaaaaaaaaaaaceaaaaaaaaaaaaaaaaaaaaacjfmipdncjfmipdnfgafbaaa
aaaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Vector 48 [_ReflectionColor]
Vector 64 [_ReflectionFalloffColor]
Float 84 [_ReflectionFalloff]
Float 88 [_ReflectionRotation]
Float 92 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
Vector 64 [_WorldSpaceCameraPos] 3
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
Matrix 192 [_Object2World]
Vector 320 [unity_Scale]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
BindCB  "UnityPerFrame" 3
"vs_4_0_level_9_3
eefieceddmfldfihfkdahicfgnbpamknnjcgbcedabaaaaaanaajaaaaaeaaaaaa
daaaaaaafeadaaaahmaiaaaaeeajaaaaebgpgodjbmadaaaabmadaaaaaaacpopp
jeacaaaaiiaaaaaaaiaaceaaaaaaieaaaaaaieaaaaaaceaaabaaieaaaaaaabaa
abaaabaaaaaaaaaaaaaaadaaaeaaacaaaaaaaaaaabaaaaaaabaaagaaaaaaaaaa
abaaaeaaabaaahaaaaaaaaaaacaaaaaaaeaaaiaaaaaaaaaaacaaamaaaeaaamaa
aaaaaaaaacaabeaaabaabaaaaaaaaaaaadaaaeaaabaabbaaaaaaaaaaaaaaaaaa
abacpoppfbaaaaafbcaaapkajkjjjjdocjfmipdnaaaaaaeaaaaaaaaabpaaaaac
afaaaaiaaaaaapjabpaaaaacafaaaciaacaaapjabpaaaaacafaaadiaadaaapja
bpaaaaacafaaafiaafaaapjaafaaaaadaaaaahiaacaaoejabaaappkaafaaaaad
abaaahiaaaaaffiaanaaoekaaeaaaaaeaaaaaliaamaakekaaaaaaaiaabaakeia
aeaaaaaeaaaaahiaaoaaoekaaaaakkiaaaaapeiaafaaaaadaaaaahiaaaaaoeia
bcaaaakaafaaaaadabaaahiaaaaaffjaanaaoekaaeaaaaaeabaaahiaamaaoeka
aaaaaajaabaaoeiaaeaaaaaeabaaahiaaoaaoekaaaaakkjaabaaoeiaaeaaaaae
abaaahiaapaaoekaaaaappjaabaaoeiaaeaaaaaeacaaadiaadaaoejaafaaoeka
afaaookaaeaaaaaeacaaamiaacaaaaibaaaaceiaabaaceiaacaaaaadabaaahia
abaaoeibahaaoekaceaaaaacadaaahiaabaaoeiaaiaaaaadaaaaabiaadaaoeia
aaaaoeiacdaaaaacaaaaadiaaaaaaaiaabaaaaacabaaadoaacaaoeiaabaaaaac
abaaaeiaaeaakkkaafaaaaadabaaabiaabaakkiaagaaaakaaeaaaaaeabaaamoa
acaaoeiabcaaffkaabaaaaiaabaaaaacaaaaamiaaeaaffkabaaaaaacaaaaapia
aaaaoeiaabaaaaacabaaapiaadaaoekaacaaaaadabaaapiaabaaoeibacaaoeka
aeaaaaaeaaaaapiaaaaakkiaabaaoeiaadaaoekaabaaaaacabaaaeiabcaakkka
abaaaaacacaaapiabbaaoekaaeaaaaaeabaaapiaacaaoeiaabaakkiaabaaoeka
bcaaaaaeacaaapiaaeaappkaabaaoeiaafaaoejaafaaaaadaaaaapoaaaaaoeia
acaaoeiaafaaaaadaaaaapiaaaaaffjaajaaoekaaeaaaaaeaaaaapiaaiaaoeka
aaaaaajaaaaaoeiaaeaaaaaeaaaaapiaakaaoekaaaaakkjaaaaaoeiaaeaaaaae
aaaaapiaalaaoekaaaaappjaaaaaoeiaaeaaaaaeaaaaadmaaaaappiaaaaaoeka
aaaaoeiaabaaaaacaaaaammaaaaaoeiappppaaaafdeieefccaafaaaaeaaaabaa
eiabaaaafjaaaaaeegiocaaaaaaaaaaaahaaaaaafjaaaaaeegiocaaaabaaaaaa
afaaaaaafjaaaaaeegiocaaaacaaaaaabfaaaaaafjaaaaaeegiocaaaadaaaaaa
afaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaadhcbabaaaacaaaaaafpaaaaad
dcbabaaaadaaaaaafpaaaaadpcbabaaaafaaaaaaghaaaaaepccabaaaaaaaaaaa
abaaaaaagfaaaaadpccabaaaabaaaaaagfaaaaaddccabaaaacaaaaaagfaaaaad
mccabaaaacaaaaaagiaaaaacaeaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaa
aaaaaaaaegiocaaaacaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaa
acaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaa
aaaaaaaaegiocaaaacaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaa
dcaaaaakpccabaaaaaaaaaaaegiocaaaacaaaaaaadaaaaaapgbpbaaaaaaaaaaa
egaobaaaaaaaaaaadiaaaaaihcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiccaaa
acaaaaaaanaaaaaadcaaaaakhcaabaaaaaaaaaaaegiccaaaacaaaaaaamaaaaaa
agbabaaaaaaaaaaaegacbaaaaaaaaaaadcaaaaakhcaabaaaaaaaaaaaegiccaaa
acaaaaaaaoaaaaaakgbkbaaaaaaaaaaaegacbaaaaaaaaaaadcaaaaakhcaabaaa
aaaaaaaaegiccaaaacaaaaaaapaaaaaapgbpbaaaaaaaaaaaegacbaaaaaaaaaaa
aaaaaaajhcaabaaaabaaaaaaegacbaiaebaaaaaaaaaaaaaaegiccaaaabaaaaaa
aeaaaaaabaaaaaahccaabaaaaaaaaaaaegacbaaaabaaaaaaegacbaaaabaaaaaa
eeaaaaafccaabaaaaaaaaaaabkaabaaaaaaaaaaadiaaaaahhcaabaaaabaaaaaa
fgafbaaaaaaaaaaaegacbaaaabaaaaaadiaaaaaihcaabaaaacaaaaaaegbcbaaa
acaaaaaapgipcaaaacaaaaaabeaaaaaadiaaaaaihcaabaaaadaaaaaafgafbaaa
acaaaaaaegiccaaaacaaaaaaanaaaaaadcaaaaaklcaabaaaacaaaaaaegiicaaa
acaaaaaaamaaaaaaagaabaaaacaaaaaaegaibaaaadaaaaaadcaaaaakhcaabaaa
acaaaaaaegiccaaaacaaaaaaaoaaaaaakgakbaaaacaaaaaaegadbaaaacaaaaaa
diaaaaakhcaabaaaacaaaaaaegacbaaaacaaaaaaaceaaaaajkjjjjdojkjjjjdo
jkjjjjdoaaaaaaaabaaaaaahccaabaaaaaaaaaaaegacbaaaabaaaaaaegacbaaa
acaaaaaacpaaaaagccaabaaaaaaaaaaabkaabaiaibaaaaaaaaaaaaaadiaaaaai
ccaabaaaaaaaaaaabkaabaaaaaaaaaaabkiacaaaaaaaaaaaafaaaaaabjaaaaaf
ccaabaaaaaaaaaaabkaabaaaaaaaaaaaaaaaaaakpcaabaaaabaaaaaaegiocaaa
aaaaaaaaadaaaaaaegiocaiaebaaaaaaaaaaaaaaaeaaaaaadcaaaaakpcaabaaa
abaaaaaafgafbaaaaaaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaaaeaaaaaa
dcaaaaaopcaabaaaadaaaaaaegiocaaaadaaaaaaaeaaaaaaaceaaaaaaaaaaaea
aaaaaaeaaaaaaaeaaaaaaaeaegiocaaaaaaaaaaaabaaaaaaaaaaaaaipcaabaaa
adaaaaaaegaobaaaadaaaaaaegbobaiaebaaaaaaafaaaaaadcaaaaakpcaabaaa
adaaaaaapgipcaaaaaaaaaaaafaaaaaaegaobaaaadaaaaaaegbobaaaafaaaaaa
diaaaaahpccabaaaabaaaaaaegaobaaaabaaaaaaegaobaaaadaaaaaadcaaaaal
kcaabaaaaaaaaaaaagbebaaaadaaaaaaagiecaaaaaaaaaaaagaaaaaakgiocaaa
aaaaaaaaagaaaaaadcaaaaakfcaabaaaaaaaaaaafgafbaiaebaaaaaaaaaaaaaa
agacbaaaacaaaaaaagacbaaaaaaaaaaadgaaaaafdccabaaaacaaaaaangafbaaa
aaaaaaaadiaaaaajccaabaaaaaaaaaaackiacaaaaaaaaaaaafaaaaaaakiacaaa
abaaaaaaaaaaaaaadcaaaaammccabaaaacaaaaaaagaibaaaaaaaaaaaaceaaaaa
aaaaaaaaaaaaaaaacjfmipdncjfmipdnfgafbaaaaaaaaaaadoaaaaabejfdeheo
maaaaaaaagaaaaaaaiaaaaaajiaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaa
apapaaaakbaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaapaaaaaakjaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaacaaaaaaahahaaaalaaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaadaaaaaaapadaaaalaaaaaaaabaaaaaaaaaaaaaaadaaaaaaaeaaaaaa
apaaaaaaljaaaaaaaaaaaaaaaaaaaaaaadaaaaaaafaaaaaaapapaaaafaepfdej
feejepeoaafeebeoehefeofeaaeoepfcenebemaafeeffiedepepfceeaaedepem
epfcaaklepfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaa
adaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaa
apaaaaaahkaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaadamaaaahkaaaaaa
abaaaaaaaaaaaaaaadaaaaaaacaaaaaaamadaaaafdfgfpfagphdgjhegjgpgoaa
edepemepfcaafeeffiedepepfceeaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Float 0 [_ReflectionIntensity]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 7 ALU, 3 TEX
PARAM c[2] = { program.local[0],
		{ 2 } };
TEMP R0;
TEMP R1;
TEMP R2;
TEX R0, fragment.texcoord[0], texture[0], 2D;
TEX R2, fragment.texcoord[0], texture[1], 2D;
MUL R1.xy, fragment.texcoord[1], c[1].x;
TEX R1, R1, texture[2], 2D;
MUL R1, R1, R2;
MUL R1, R1, c[0].x;
MAD result.color, fragment.color.primary, R1, R0;
END
# 7 instructions, 3 R-regs
"
}
SubProgram "d3d9 " {
Float 0 [_ReflectionIntensity]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
"ps_2_0
; 5 ALU, 3 TEX
dcl_2d s0
dcl_2d s1
dcl_2d s2
def c1, 2.00000000, 0, 0, 0
dcl v0
dcl t0.xy
dcl t1.xy
texld r2, t0, s0
texld r1, t0, s1
mul r0.xy, t1, c1.x
texld r0, r0, s2
mul r0, r0, r1
mul r0, r0, c0.x
mad_pp r0, v0, r0, r2
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
ConstBuffer "$Globals" 112
Float 80 [_ReflectionIntensity]
BindCB  "$Globals" 0
"ps_4_0
eefieceddpimaokeaebhinihllpneadanelhinkoabaaaaaaieacaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaapapaaaahkaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
adadaaaahkaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaaamamaaaafdfgfpfa
gphdgjhegjgpgoaaedepemepfcaafeeffiedepepfceeaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcjaabaaaaeaaaaaaageaaaaaafjaaaaae
egiocaaaaaaaaaaaagaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaa
abaaaaaafkaaaaadaagabaaaacaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaa
fibiaaaeaahabaaaabaaaaaaffffaaaafibiaaaeaahabaaaacaaaaaaffffaaaa
gcbaaaadpcbabaaaabaaaaaagcbaaaaddcbabaaaacaaaaaagcbaaaadmcbabaaa
acaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacacaaaaaaaaaaaaahdcaabaaa
aaaaaaaaogbkbaaaacaaaaaaogbkbaaaacaaaaaaefaaaaajpcaabaaaaaaaaaaa
egaabaaaaaaaaaaaeghobaaaacaaaaaaaagabaaaacaaaaaaefaaaaajpcaabaaa
abaaaaaaegbabaaaacaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaadiaaaaah
pcaabaaaaaaaaaaaegaobaaaaaaaaaaaegaobaaaabaaaaaadiaaaaaipcaabaaa
aaaaaaaaegaobaaaaaaaaaaaagiacaaaaaaaaaaaafaaaaaaefaaaaajpcaabaaa
abaaaaaaegbabaaaacaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaadcaaaaaj
pccabaaaaaaaaaaaegbobaaaabaaaaaaegaobaaaaaaaaaaaegaobaaaabaaaaaa
doaaaaab"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
ConstBuffer "$Globals" 112
Float 80 [_ReflectionIntensity]
BindCB  "$Globals" 0
"ps_4_0_level_9_3
eefieceddlgbcblhmkfnhenmeljmkmeihioekbjjabaaaaaajaadaaaaaeaaaaaa
daaaaaaadiabaaaanaacaaaafmadaaaaebgpgodjaaabaaaaaaabaaaaaaacpppp
meaaaaaadmaaaaaaabaadaaaaaaadmaaaaaadmaaadaaceaaaaaadmaaaaaaaaaa
abababaaacacacaaaaaaafaaabaaaaaaaaaaaaaaabacppppbpaaaaacaaaaaaia
aaaacplabpaaaaacaaaaaaiaabaaaplabpaaaaacaaaaaajaaaaiapkabpaaaaac
aaaaaajaabaiapkabpaaaaacaaaaaajaacaiapkaacaaaaadaaaaadiaabaaolla
abaaollaecaaaaadabaacpiaabaaoelaabaioekaecaaaaadaaaaapiaaaaaoeia
acaioekaafaaaaadaaaaapiaabaaoeiaaaaaoeiaafaaaaadaaaacpiaaaaaoeia
aaaaaakaecaaaaadabaacpiaabaaoelaaaaioekaaeaaaaaeaaaacpiaaaaaoela
aaaaoeiaabaaoeiaabaaaaacaaaicpiaaaaaoeiappppaaaafdeieefcjaabaaaa
eaaaaaaageaaaaaafjaaaaaeegiocaaaaaaaaaaaagaaaaaafkaaaaadaagabaaa
aaaaaaaafkaaaaadaagabaaaabaaaaaafkaaaaadaagabaaaacaaaaaafibiaaae
aahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaaffffaaaafibiaaae
aahabaaaacaaaaaaffffaaaagcbaaaadpcbabaaaabaaaaaagcbaaaaddcbabaaa
acaaaaaagcbaaaadmcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaac
acaaaaaaaaaaaaahdcaabaaaaaaaaaaaogbkbaaaacaaaaaaogbkbaaaacaaaaaa
efaaaaajpcaabaaaaaaaaaaaegaabaaaaaaaaaaaeghobaaaacaaaaaaaagabaaa
acaaaaaaefaaaaajpcaabaaaabaaaaaaegbabaaaacaaaaaaeghobaaaabaaaaaa
aagabaaaabaaaaaadiaaaaahpcaabaaaaaaaaaaaegaobaaaaaaaaaaaegaobaaa
abaaaaaadiaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaaagiacaaaaaaaaaaa
afaaaaaaefaaaaajpcaabaaaabaaaaaaegbabaaaacaaaaaaeghobaaaaaaaaaaa
aagabaaaaaaaaaaadcaaaaajpccabaaaaaaaaaaaegbobaaaabaaaaaaegaobaaa
aaaaaaaaegaobaaaabaaaaaadoaaaaabejfdeheoieaaaaaaaeaaaaaaaiaaaaaa
giaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaabaaaaaaapapaaaahkaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
acaaaaaaadadaaaahkaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaaamamaaaa
fdfgfpfagphdgjhegjgpgoaaedepemepfcaafeeffiedepepfceeaaklepfdeheo
cmaaaaaaabaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaa
apaaaaaafdfgfpfegbhcghgfheaaklkl"
}
}
 }
}
Fallback "Diffuse"
}