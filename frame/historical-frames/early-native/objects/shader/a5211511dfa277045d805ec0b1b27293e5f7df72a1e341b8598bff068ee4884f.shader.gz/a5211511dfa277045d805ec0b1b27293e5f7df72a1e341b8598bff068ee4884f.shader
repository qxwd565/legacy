Shader "Custom/Card/MissingCardDesaturateAlpha" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondScaleUV ("Second UV Scale", Float) = 1
 _SecondIntensity ("SecondIntensity", Float) = 1
 _Color ("Color", Color) = (0.5,0.5,0.5,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
  BindChannels {
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog { Mode Off }
  Blend SrcAlpha OneMinusSrcAlpha
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Vector 6 [_LightColor0]
Float 7 [_SecondScaleUV]
Float 8 [_LightingBlend]
Vector 9 [_MainTex_ST]
"!!ARBvp1.0
# 11 ALU
PARAM c[10] = { { 2 },
		state.lightmodel.ambient,
		state.matrix.mvp,
		program.local[6..9] };
TEMP R0;
MOV R0.x, c[0];
MUL R0, R0.x, c[1];
ADD R0, R0, c[6];
ADD R0, R0, -vertex.color;
MAD result.color, R0, c[8].x, vertex.color;
MAD result.texcoord[0].xy, vertex.texcoord[0], c[9], c[9].zwzw;
MUL result.texcoord[1].xy, vertex.position.xzzw, c[7].x;
DP4 result.position.w, vertex.position, c[5];
DP4 result.position.z, vertex.position, c[4];
DP4 result.position.y, vertex.position, c[3];
DP4 result.position.x, vertex.position, c[2];
END
# 11 instructions, 1 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Matrix 0 [glstate_matrix_mvp]
Vector 4 [glstate_lightmodel_ambient]
Vector 5 [_LightColor0]
Float 6 [_SecondScaleUV]
Float 7 [_LightingBlend]
Vector 8 [_MainTex_ST]
"vs_2_0
; 11 ALU
def c9, 2.00000000, 0, 0, 0
dcl_position0 v0
dcl_texcoord0 v1
dcl_color0 v2
mov r0, c4
mul r0, c9.x, r0
add r0, r0, c5
add r0, r0, -v2
mad oD0, r0, c7.x, v2
mad oT0.xy, v1, c8, c8.zwzw
mul oT1.xy, v0.xzzw, c6.x
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 144
Vector 16 [_LightColor0]
Float 48 [_SecondScaleUV]
Float 112 [_LightingBlend]
Vector 128 [_MainTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
BindCB  "UnityPerFrame" 2
"vs_4_0
eefiecednjjeoakobbnepjhjkibdlbplmloibpecabaaaaaadaadaaaaadaaaaaa
cmaaaaaajmaaaaaaciabaaaaejfdeheogiaaaaaaadaaaaaaaiaaaaaafaaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaagcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apapaaaafaepfdejfeejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheo
ieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaa
apaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaa
abaaaaaaaaaaaaaaadaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaacaaaaaaapaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfcee
aaedepemepfcaaklfdeieefcaaacaaaaeaaaabaaiaaaaaaafjaaaaaeegiocaaa
aaaaaaaaajaaaaaafjaaaaaeegiocaaaabaaaaaaaeaaaaaafjaaaaaeegiocaaa
acaaaaaaafaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaa
fpaaaaadpcbabaaaacaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaad
dccabaaaabaaaaaagfaaaaadmccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaa
giaaaaacabaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaa
abaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaaaaaaaaa
agbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaa
abaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaa
aaaaaaaaegiocaaaabaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaa
dcaaaaaldccabaaaabaaaaaaegbabaaaabaaaaaaegiacaaaaaaaaaaaaiaaaaaa
ogikcaaaaaaaaaaaaiaaaaaadiaaaaaimccabaaaabaaaaaaagbibaaaaaaaaaaa
agiacaaaaaaaaaaaadaaaaaadcaaaaaopcaabaaaaaaaaaaaegiocaaaacaaaaaa
aeaaaaaaaceaaaaaaaaaaaeaaaaaaaeaaaaaaaeaaaaaaaeaegiocaaaaaaaaaaa
abaaaaaaaaaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaiaebaaaaaa
acaaaaaadcaaaaakpccabaaaacaaaaaaagiacaaaaaaaaaaaahaaaaaaegaobaaa
aaaaaaaaegbobaaaacaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 144
Vector 16 [_LightColor0]
Float 48 [_SecondScaleUV]
Float 112 [_LightingBlend]
Vector 128 [_MainTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
BindCB  "UnityPerFrame" 2
"vs_4_0_level_9_3
eefiecedmgcioeibkoedmcldneabkckeioodpbcfabaaaaaameaeaaaaaeaaaaaa
daaaaaaamaabaaaamiadaaaadiaeaaaaebgpgodjiiabaaaaiiabaaaaaaacpopp
ceabaaaageaaaaaaafaaceaaaaaagaaaaaaagaaaaaaaceaaabaagaaaaaaaabaa
abaaabaaaaaaaaaaaaaaadaaabaaacaaaaaaaaaaaaaaahaaacaaadaaaaaaaaaa
abaaaaaaaeaaafaaaaaaaaaaacaaaeaaabaaajaaaaaaaaaaaaaaaaaaabacpopp
fbaaaaafakaaapkaaaaaaaeaaaaaaaaaaaaaaaaaaaaaaaaabpaaaaacafaaaaia
aaaaapjabpaaaaacafaaabiaabaaapjabpaaaaacafaaaciaacaaapjaaeaaaaae
aaaaadoaabaaoejaaeaaoekaaeaaookaafaaaaadaaaaamoaaaaacejaacaaaaka
abaaaaacaaaaapiaajaaoekaabaaaaacabaaabiaakaaaakaaeaaaaaeaaaaapia
aaaaoeiaabaaaaiaabaaoekaacaaaaadaaaaapiaaaaaoeiaacaaoejbaeaaaaae
abaaapoaadaaaakaaaaaoeiaacaaoejaafaaaaadaaaaapiaaaaaffjaagaaoeka
aeaaaaaeaaaaapiaafaaoekaaaaaaajaaaaaoeiaaeaaaaaeaaaaapiaahaaoeka
aaaakkjaaaaaoeiaaeaaaaaeaaaaapiaaiaaoekaaaaappjaaaaaoeiaaeaaaaae
aaaaadmaaaaappiaaaaaoekaaaaaoeiaabaaaaacaaaaammaaaaaoeiappppaaaa
fdeieefcaaacaaaaeaaaabaaiaaaaaaafjaaaaaeegiocaaaaaaaaaaaajaaaaaa
fjaaaaaeegiocaaaabaaaaaaaeaaaaaafjaaaaaeegiocaaaacaaaaaaafaaaaaa
fpaaaaadpcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaadpcbabaaa
acaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaaabaaaaaa
gfaaaaadmccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaacabaaaaaa
diaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaabaaaaaaabaaaaaa
dcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaaaaaaaaaagbabaaaaaaaaaaa
egaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaacaaaaaa
kgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaa
abaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaaldccabaaa
abaaaaaaegbabaaaabaaaaaaegiacaaaaaaaaaaaaiaaaaaaogikcaaaaaaaaaaa
aiaaaaaadiaaaaaimccabaaaabaaaaaaagbibaaaaaaaaaaaagiacaaaaaaaaaaa
adaaaaaadcaaaaaopcaabaaaaaaaaaaaegiocaaaacaaaaaaaeaaaaaaaceaaaaa
aaaaaaeaaaaaaaeaaaaaaaeaaaaaaaeaegiocaaaaaaaaaaaabaaaaaaaaaaaaai
pcaabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaiaebaaaaaaacaaaaaadcaaaaak
pccabaaaacaaaaaaagiacaaaaaaaaaaaahaaaaaaegaobaaaaaaaaaaaegbobaaa
acaaaaaadoaaaaabejfdeheogiaaaaaaadaaaaaaaiaaaaaafaaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaaaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
abaaaaaaadadaaaagcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaa
faepfdejfeejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheoieaaaaaa
aeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaa
heaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaa
aaaaaaaaadaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
acaaaaaaapaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepem
epfcaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Float 0 [_SecondIntensity]
Vector 1 [_Color]
Float 2 [_Desaturate]
Float 3 [_Contrast]
Float 4 [_Intensity]
Vector 5 [_AvgLum]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 14 ALU, 2 TEX
PARAM c[7] = { program.local[0..5],
		{ 0.30004883, 0.58984375, 0.10998535, 1 } };
TEMP R0;
TEMP R1;
TEMP R2;
TEX R0, fragment.texcoord[0], texture[0], 2D;
TEX R2.x, fragment.texcoord[1], texture[1], 2D;
DP3 R1.w, R0, c[6];
ADD R1.xyz, R1.w, -R0;
MAD R0.xyz, R1, c[2].x, R0;
ADD R1.xyz, -R0, c[5];
MAD R0.xyz, R1, c[3].x, R0;
ADD R1.x, -R1.w, c[6].w;
MUL_SAT R1.y, R2.x, c[0].x;
MUL R0.w, R1.x, R0;
MUL R0.w, R0, R1.y;
MUL R0, R0, c[1];
MUL R0, R0, c[4].x;
MUL result.color, R0, fragment.color.primary;
END
# 14 instructions, 3 R-regs
"
}
SubProgram "d3d9 " {
Float 0 [_SecondIntensity]
Vector 1 [_Color]
Float 2 [_Desaturate]
Float 3 [_Contrast]
Float 4 [_Intensity]
Vector 5 [_AvgLum]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
"ps_2_0
; 13 ALU, 2 TEX
dcl_2d s0
dcl_2d s1
def c6, 0.30004883, 0.58984375, 0.10998535, 1.00000000
dcl t0.xy
dcl t1.xy
dcl v0
texld r1, t0, s0
texld r2, t1, s1
dp3_pp r0.x, r1, c6
add_pp r3.xyz, r0.x, -r1
mad_pp r1.xyz, r3, c2.x, r1
add_pp r3.xyz, -r1, c5
add_pp r0.x, -r0, c6.w
mad_pp r3.xyz, r3, c3.x, r1
mul_pp r0.x, r0, r1.w
mul_sat r1.x, r2, c0
mul_pp r3.w, r0.x, r1.x
mul_pp r0, r3, c1
mul_pp r0, r0, c4.x
mul_pp r0, r0, v0
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
ConstBuffer "$Globals" 144
Float 52 [_SecondIntensity]
Vector 64 [_Color]
Float 80 [_Desaturate]
Float 84 [_Contrast]
Float 88 [_Intensity]
Vector 96 [_AvgLum]
BindCB  "$Globals" 0
"ps_4_0
eefiecedjmoopgaionmbogefnhmmeocagkmbjmcmabaaaaaafiadaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcgeacaaaaeaaaaaaajjaaaaaafjaaaaae
egiocaaaaaaaaaaaahaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaa
abaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaa
ffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaadmcbabaaaabaaaaaagcbaaaad
pcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacadaaaaaaefaaaaaj
pcaabaaaaaaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaa
baaaaaakbcaabaaaabaaaaaaaceaaaaajkjjjjdodnakbhdpkoehobdnaaaaaaaa
egacbaaaaaaaaaaaaaaaaaaiocaabaaaabaaaaaaagajbaiaebaaaaaaaaaaaaaa
agaabaaaabaaaaaaaaaaaaaibcaabaaaabaaaaaaakaabaiaebaaaaaaabaaaaaa
abeaaaaaaaaaiadpdiaaaaahicaabaaaaaaaaaaadkaabaaaaaaaaaaaakaabaaa
abaaaaaadcaaaaakhcaabaaaaaaaaaaaagiacaaaaaaaaaaaafaaaaaajgahbaaa
abaaaaaaegacbaaaaaaaaaaaaaaaaaajhcaabaaaabaaaaaaegacbaiaebaaaaaa
aaaaaaaaegiccaaaaaaaaaaaagaaaaaadcaaaaakhcaabaaaabaaaaaafgifcaaa
aaaaaaaaafaaaaaaegacbaaaabaaaaaaegacbaaaaaaaaaaaefaaaaajpcaabaaa
acaaaaaaogbkbaaaabaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaadicaaaai
bcaabaaaaaaaaaaaakaabaaaacaaaaaabkiacaaaaaaaaaaaadaaaaaadiaaaaah
icaabaaaabaaaaaaakaabaaaaaaaaaaadkaabaaaaaaaaaaadiaaaaaipcaabaaa
aaaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaaaeaaaaaadiaaaaaipcaabaaa
aaaaaaaaegaobaaaaaaaaaaakgikcaaaaaaaaaaaafaaaaaadiaaaaahpccabaaa
aaaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
ConstBuffer "$Globals" 144
Float 52 [_SecondIntensity]
Vector 64 [_Color]
Float 80 [_Desaturate]
Float 84 [_Contrast]
Float 88 [_Intensity]
Vector 96 [_AvgLum]
BindCB  "$Globals" 0
"ps_4_0_level_9_3
eefiecedlaplidmcghmooniiahnelggeaajmdidoabaaaaaanmaeaaaaaeaaaaaa
daaaaaaalaabaaaabmaeaaaakiaeaaaaebgpgodjhiabaaaahiabaaaaaaacpppp
eaabaaaadiaaaaaaabaacmaaaaaadiaaaaaadiaaacaaceaaaaaadiaaaaaaaaaa
abababaaaaaaadaaaeaaaaaaaaaaaaaaabacppppfbaaaaafaeaaapkajkjjjjdo
dnakbhdpkoehobdnaaaaiadpbpaaaaacaaaaaaiaaaaaaplabpaaaaacaaaaaaia
abaacplabpaaaaacaaaaaajaaaaiapkabpaaaaacaaaaaajaabaiapkaabaaaaac
aaaaadiaaaaaollaecaaaaadabaacpiaaaaaoelaaaaioekaecaaaaadaaaaapia
aaaaoeiaabaioekaafaaaaadaaaadbiaaaaaaaiaaaaaffkaaiaaaaadaaaaccia
aeaaoekaabaaoeiaacaaaaadaaaaceiaaaaaffibaeaappkabcaaaaaeacaachia
acaaaakaaaaaffiaabaaoeiaafaaaaadacaaciiaabaappiaaaaakkiaafaaaaad
aaaaciiaaaaaaaiaacaappiaacaaaaadabaachiaacaaoeibadaaoekaaeaaaaae
aaaachiaacaaffkaabaaoeiaacaaoeiaafaaaaadaaaacpiaaaaaoeiaabaaoeka
afaaaaadaaaacpiaaaaaoeiaacaakkkaafaaaaadaaaacpiaaaaaoeiaabaaoela
abaaaaacaaaicpiaaaaaoeiappppaaaafdeieefcgeacaaaaeaaaaaaajjaaaaaa
fjaaaaaeegiocaaaaaaaaaaaahaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaad
aagabaaaabaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaa
abaaaaaaffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaadmcbabaaaabaaaaaa
gcbaaaadpcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacadaaaaaa
efaaaaajpcaabaaaaaaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaa
aaaaaaaabaaaaaakbcaabaaaabaaaaaaaceaaaaajkjjjjdodnakbhdpkoehobdn
aaaaaaaaegacbaaaaaaaaaaaaaaaaaaiocaabaaaabaaaaaaagajbaiaebaaaaaa
aaaaaaaaagaabaaaabaaaaaaaaaaaaaibcaabaaaabaaaaaaakaabaiaebaaaaaa
abaaaaaaabeaaaaaaaaaiadpdiaaaaahicaabaaaaaaaaaaadkaabaaaaaaaaaaa
akaabaaaabaaaaaadcaaaaakhcaabaaaaaaaaaaaagiacaaaaaaaaaaaafaaaaaa
jgahbaaaabaaaaaaegacbaaaaaaaaaaaaaaaaaajhcaabaaaabaaaaaaegacbaia
ebaaaaaaaaaaaaaaegiccaaaaaaaaaaaagaaaaaadcaaaaakhcaabaaaabaaaaaa
fgifcaaaaaaaaaaaafaaaaaaegacbaaaabaaaaaaegacbaaaaaaaaaaaefaaaaaj
pcaabaaaacaaaaaaogbkbaaaabaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaa
dicaaaaibcaabaaaaaaaaaaaakaabaaaacaaaaaabkiacaaaaaaaaaaaadaaaaaa
diaaaaahicaabaaaabaaaaaaakaabaaaaaaaaaaadkaabaaaaaaaaaaadiaaaaai
pcaabaaaaaaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaaaeaaaaaadiaaaaai
pcaabaaaaaaaaaaaegaobaaaaaaaaaaakgikcaaaaaaaaaaaafaaaaaadiaaaaah
pccabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaadoaaaaabejfdeheo
ieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaa
apaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadadaaaaheaaaaaa
abaaaaaaaaaaaaaaadaaaaaaabaaaaaaamamaaaahnaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaacaaaaaaapapaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfcee
aaedepemepfcaaklepfdeheocmaaaaaaabaaaaaaaiaaaaaacaaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaaaaaaaaaapaaaaaafdfgfpfegbhcghgfheaaklkl"
}
}
 }
}
Fallback Off
}