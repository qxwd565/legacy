Shader "Hero/DiffuseAlphaMaskScroller" {
Properties {
 _MainTex ("_MainTex", 2D) = "black" {}
 _ScrollingTex ("_ScrollingTex", 2D) = "black" {}
 _tint ("_tint", Color) = (1,1,1,1)
 _Fade ("_Fade", Color) = (1,1,1,1)
 _YSpeed ("_YSpeed", Float) = 0.1
 _XSpeed ("_XSpeed", Float) = 0.1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" }
 Pass {
  Tags { "RenderType"="Opaque" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "texcoord", TexCoord
   Bind "texcoord1", TexCoord1
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform highp vec4 _MainTex_ST;
uniform mediump float _LightingBlend;
uniform lowp vec4 _LightColor0;
uniform highp vec4 glstate_lightmodel_ambient;
uniform highp mat4 glstate_matrix_mvp;
attribute vec4 _glesMultiTexCoord1;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesVertex;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = mix (vec4(1.0, 1.0, 1.0, 1.0), ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((_glesMultiTexCoord1.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

varying lowp vec4 xlv_COLOR;
varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
uniform mediump float _XSpeed;
uniform mediump float _YSpeed;
uniform mediump vec4 _Fade;
uniform mediump vec4 _tint;
uniform sampler2D _ScrollingTex;
uniform sampler2D _MainTex;
uniform highp vec4 _Time;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 TexMask_2;
  mediump vec4 Tex2D1_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0);
  Tex2D1_3 = tmpvar_4;
  highp vec2 tmpvar_5;
  tmpvar_5.x = (xlv_TEXCOORD1.x + (_Time.x * _XSpeed));
  tmpvar_5.y = (xlv_TEXCOORD1.y + (_Time.x * _YSpeed));
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_ScrollingTex, tmpvar_5);
  TexMask_2 = tmpvar_6;
  mediump vec4 tmpvar_7;
  tmpvar_7.w = 1.0;
  tmpvar_7.xyz = ((Tex2D1_3.xyz + (((TexMask_2.x * _tint.xyz) * Tex2D1_3.w) * 1.5)) * _Fade.xyz);
  tmpvar_1 = (tmpvar_7 * xlv_COLOR);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback Off
}