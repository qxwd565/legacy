Shader "Effects/FX_Desaturate" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _Color ("Light Color", Color) = (0.6,0.6,0.6,1)
 _DarkColor ("Dark Color", Color) = (0.3,0.3,0.3,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
}
SubShader { 
 Tags { "RenderType"="Opaque" }
 Pass {
  Tags { "RenderType"="Opaque" }
  BindChannels {
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

varying highp vec2 xlv_TEXCOORD0;
uniform highp vec4 _MainTex_ST;
uniform highp mat4 glstate_matrix_mvp;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesVertex;
void main ()
{
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
}



#endif
#ifdef FRAGMENT

varying highp vec2 xlv_TEXCOORD0;
uniform lowp vec4 _AvgLum;
uniform highp float _Intensity;
uniform highp float _Contrast;
uniform mediump float _Desaturate;
uniform lowp vec4 _DarkColor;
uniform lowp vec4 _Color;
uniform sampler2D _MainTex;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  mediump vec4 tmpvar_4;
  tmpvar_4 = mix (col_2, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), col_2.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (tmpvar_4, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_5;
  tmpvar_1 = (col_2 * _Intensity);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback Off
}