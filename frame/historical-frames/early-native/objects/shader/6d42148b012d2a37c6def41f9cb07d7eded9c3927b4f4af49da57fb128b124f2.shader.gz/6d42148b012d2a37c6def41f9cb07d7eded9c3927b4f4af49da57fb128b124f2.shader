Shader "Custom/FX_GhostCard" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "black" {}
 _TexIntensity ("Main Texture Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "black" {}
 _FxIntensity ("FX Intensity", Float) = 1
 _FxDistortion ("FX Distortion", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="True" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Vector 5 [_Time]
Float 6 [_ScrollX]
Float 7 [_ScrollY]
Float 8 [_ScaleX]
Float 9 [_ScaleY]
Float 10 [_Seed]
Vector 11 [_MainTex_ST]
"!!ARBvp1.0
# 15 ALU
PARAM c[12] = { program.local[0],
		state.matrix.mvp,
		program.local[5..11] };
TEMP R0;
MAD R0.xy, vertex.texcoord[0], c[11], c[11].zwzw;
MOV R0.z, c[6].x;
MOV R0.w, c[7].x;
MOV result.texcoord[0].xy, R0;
MUL R0.z, R0, c[5].x;
MUL R0.w, R0, c[5].x;
MAD R0.x, R0, c[8], R0.z;
MAD R0.y, R0, c[9].x, R0.w;
MOV result.color, vertex.color;
ADD result.texcoord[1].x, R0, c[10];
ADD result.texcoord[1].y, R0, c[10].x;
DP4 result.position.w, vertex.position, c[4];
DP4 result.position.z, vertex.position, c[3];
DP4 result.position.y, vertex.position, c[2];
DP4 result.position.x, vertex.position, c[1];
END
# 15 instructions, 1 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
Matrix 0 [glstate_matrix_mvp]
Vector 4 [_Time]
Float 5 [_ScrollX]
Float 6 [_ScrollY]
Float 7 [_ScaleX]
Float 8 [_ScaleY]
Float 9 [_Seed]
Vector 10 [_MainTex_ST]
"vs_2_0
; 15 ALU
dcl_position0 v0
dcl_texcoord0 v1
dcl_color0 v2
mad r0.xy, v1, c10, c10.zwzw
mov r0.z, c4.x
mov r0.w, c4.x
mov oT0.xy, r0
mul r0.z, c5.x, r0
mul r0.w, c6.x, r0
mad r0.x, r0, c7, r0.z
mad r0.y, r0, c8.x, r0.w
mov oD0, v2
add oT1.x, r0, c9
add oT1.y, r0, c9.x
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 96
Float 60 [_ScrollX]
Float 64 [_ScrollY]
Float 68 [_ScaleX]
Float 72 [_ScaleY]
Float 76 [_Seed]
Vector 80 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
"vs_4_0
eefiecedhkmbgkajgbinhjcaohdokelhcknmfmkgabaaaaaafaadaaaaadaaaaaa
cmaaaaaajmaaaaaaciabaaaaejfdeheogiaaaaaaadaaaaaaaiaaaaaafaaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaagcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apapaaaafaepfdejfeejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheo
ieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaa
apaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaa
abaaaaaaaaaaaaaaadaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaacaaaaaaapaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfcee
aaedepemepfcaaklfdeieefccaacaaaaeaaaabaaiiaaaaaafjaaaaaeegiocaaa
aaaaaaaaagaaaaaafjaaaaaeegiocaaaabaaaaaaabaaaaaafjaaaaaeegiocaaa
acaaaaaaaeaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaa
fpaaaaadpcbabaaaacaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaad
dccabaaaabaaaaaagfaaaaadmccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaa
giaaaaacabaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaa
acaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaacaaaaaaaaaaaaaa
agbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaa
acaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaa
aaaaaaaaegiocaaaacaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaa
dcaaaaaldcaabaaaaaaaaaaaegbabaaaabaaaaaaegiacaaaaaaaaaaaafaaaaaa
ogikcaaaaaaaaaaaafaaaaaadiaaaaaimcaabaaaaaaaaaaaagaebaaaaaaaaaaa
fgijcaaaaaaaaaaaaeaaaaaadgaaaaafdccabaaaabaaaaaaegaabaaaaaaaaaaa
dcaaaaalbcaabaaaaaaaaaaaakiacaaaabaaaaaaaaaaaaaadkiacaaaaaaaaaaa
adaaaaaackaabaaaaaaaaaaadcaaaaalccaabaaaaaaaaaaaakiacaaaabaaaaaa
aaaaaaaaakiacaaaaaaaaaaaaeaaaaaadkaabaaaaaaaaaaaaaaaaaaimccabaaa
abaaaaaaagaebaaaaaaaaaaapgipcaaaaaaaaaaaaeaaaaaadgaaaaafpccabaaa
acaaaaaaegbobaaaacaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 96
Float 60 [_ScrollX]
Float 64 [_ScrollY]
Float 68 [_ScaleX]
Float 72 [_ScaleY]
Float 76 [_Seed]
Vector 80 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
"vs_4_0_level_9_1
eefiecedoaplalnnldkbbjlnilbjmfmnfpehekpnabaaaaaamaaeaaaaaeaaaaaa
daaaaaaajmabaaaameadaaaadeaeaaaaebgpgodjgeabaaaageabaaaaaaacpopp
biabaaaaemaaaaaaadaaceaaaaaaeiaaaaaaeiaaaaaaceaaabaaeiaaaaaaadaa
adaaabaaaaaaaaaaabaaaaaaabaaaeaaaaaaaaaaacaaaaaaaeaaafaaaaaaaaaa
aaaaaaaaaaacpoppbpaaaaacafaaaaiaaaaaapjabpaaaaacafaaabiaabaaapja
bpaaaaacafaaaciaacaaapjaaeaaaaaeaaaaadiaabaaoejaadaaoekaadaaooka
afaaaaadaaaaamiaaaaaeeiaacaajekaabaaaaacaaaaadoaaaaaoeiaabaaaaac
aaaaabiaaeaaaakaaeaaaaaeaaaaaciaaaaaaaiaabaappkaaaaakkiaaeaaaaae
aaaaabiaaaaaaaiaacaaaakaaaaappiaacaaaaadaaaaamoaaaaaeeiaacaappka
afaaaaadaaaaapiaaaaaffjaagaaoekaaeaaaaaeaaaaapiaafaaoekaaaaaaaja
aaaaoeiaaeaaaaaeaaaaapiaahaaoekaaaaakkjaaaaaoeiaaeaaaaaeaaaaapia
aiaaoekaaaaappjaaaaaoeiaaeaaaaaeaaaaadmaaaaappiaaaaaoekaaaaaoeia
abaaaaacaaaaammaaaaaoeiaabaaaaacabaaapoaacaaoejappppaaaafdeieefc
caacaaaaeaaaabaaiiaaaaaafjaaaaaeegiocaaaaaaaaaaaagaaaaaafjaaaaae
egiocaaaabaaaaaaabaaaaaafjaaaaaeegiocaaaacaaaaaaaeaaaaaafpaaaaad
pcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaadpcbabaaaacaaaaaa
ghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaaabaaaaaagfaaaaad
mccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaacabaaaaaadiaaaaai
pcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaacaaaaaaabaaaaaadcaaaaak
pcaabaaaaaaaaaaaegiocaaaacaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaa
aaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaacaaaaaaacaaaaaakgbkbaaa
aaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaacaaaaaa
adaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaaldcaabaaaaaaaaaaa
egbabaaaabaaaaaaegiacaaaaaaaaaaaafaaaaaaogikcaaaaaaaaaaaafaaaaaa
diaaaaaimcaabaaaaaaaaaaaagaebaaaaaaaaaaafgijcaaaaaaaaaaaaeaaaaaa
dgaaaaafdccabaaaabaaaaaaegaabaaaaaaaaaaadcaaaaalbcaabaaaaaaaaaaa
akiacaaaabaaaaaaaaaaaaaadkiacaaaaaaaaaaaadaaaaaackaabaaaaaaaaaaa
dcaaaaalccaabaaaaaaaaaaaakiacaaaabaaaaaaaaaaaaaaakiacaaaaaaaaaaa
aeaaaaaadkaabaaaaaaaaaaaaaaaaaaimccabaaaabaaaaaaagaebaaaaaaaaaaa
pgipcaaaaaaaaaaaaeaaaaaadgaaaaafpccabaaaacaaaaaaegbobaaaacaaaaaa
doaaaaabejfdeheogiaaaaaaadaaaaaaaiaaaaaafaaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaaaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaa
adadaaaagcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafaepfdej
feejepeoaafeeffiedepepfceeaaedepemepfcaaepfdeheoieaaaaaaaeaaaaaa
aiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaaaaaaaaaa
adaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaakl
"
}
}
Program "fp" {
SubProgram "opengl " {
Float 0 [_TexIntensity]
Vector 1 [_Color]
Float 2 [_Intensity]
Float 3 [_FxIntensity]
Float 4 [_FxDistortion]
SetTexture 0 [_FxTex] 2D 0
SetTexture 1 [_MainTex] 2D 1
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 23 ALU, 2 TEX
PARAM c[8] = { program.local[0..4],
		{ 2, 0.010002136, 0.0050010681, 0.70019531 },
		{ 0.30004883, 0.58984375, 0.10998535 },
		{ 1.2001953, 1.7001953, 1.4003906 } };
TEMP R0;
TEMP R1;
TEMP R2;
TEX R0.x, fragment.texcoord[1], texture[0], 2D;
MUL R2.x, R0, c[3];
MUL R0.x, R2, c[4];
MUL R0.y, R0.x, c[5].z;
MUL R0.x, R0, c[5].y;
MUL R1.xyz, R2.x, c[1];
ADD R0.y, fragment.texcoord[0], R0;
ADD R0.x, fragment.texcoord[0], R0;
MUL R1.xyz, R1, c[5].x;
MOV R1.w, R2.x;
MUL R1, R1, R2.x;
MUL R1, R1, c[2].x;
MUL R1, R1, fragment.color.primary;
TEX R0, R0, texture[1], 2D;
MUL R0, R0, c[0].x;
MAD R1, R1, c[5].x, R0;
MUL R0, R1, R0.w;
MUL R1, R0, c[1].w;
MOV R0.w, R1;
DP3 R0.xyz, R1, c[6];
ADD R0, R0, -R1;
MAD R0, R0, c[5].w, R1;
MUL_SAT result.color, R0, c[7].xxyz;
END
# 23 instructions, 3 R-regs
"
}
SubProgram "d3d9 " {
Float 0 [_TexIntensity]
Vector 1 [_Color]
Float 2 [_Intensity]
Float 3 [_FxIntensity]
Float 4 [_FxDistortion]
SetTexture 0 [_FxTex] 2D 0
SetTexture 1 [_MainTex] 2D 1
"ps_2_0
; 25 ALU, 2 TEX
dcl_2d s0
dcl_2d s1
def c5, 2.00000000, 0.01000214, 0.00500107, 0.70019531
def c6, 0.30004883, 0.58984375, 0.10998535, 0
def c7, 1.20019531, 1.70019531, 1.40039063, 0
dcl t0.xy
dcl t1.xy
dcl v0
texld r0, t1, s0
mul r0.x, r0, c3
mul_pp r1.x, r0, c4
mul_pp r2.x, r1, c5.z
add r1.y, t0, r2.x
mul_pp r2.xyz, r0.x, c1
mul_pp r1.x, r1, c5.y
add r1.x, t0, r1
mul_pp r2.xyz, r2, c5.x
mov_pp r2.w, r0.x
mul_pp r0, r2, r0.x
mul r0, r0, c2.x
mul r0, r0, v0
texld r1, r1, s1
mul r1, r1, c0.x
mad r0, r0, c5.x, r1
mul r0, r0, r1.w
mul r1, r0, c1.w
mov_pp r0.w, r1
dp3_pp r0.xyz, r1, c6
add_pp r0, r0, -r1
mad_pp r1, r0, c5.w, r1
mov r0.xy, c7.x
mov r0.w, c7.z
mov r0.z, c7.y
mul_pp_sat r0, r1, r0
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_FxTex] 2D 1
SetTexture 1 [_MainTex] 2D 0
ConstBuffer "$Globals" 96
Float 16 [_TexIntensity]
Vector 32 [_Color]
Float 48 [_Intensity]
Float 52 [_FxIntensity]
Float 56 [_FxDistortion]
BindCB  "$Globals" 0
"ps_4_0
eefiecedhlamhkcohkbaboicbhpckbbpadnmachnabaaaaaabmaeaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcciadaaaaeaaaaaaamkaaaaaafjaaaaae
egiocaaaaaaaaaaaaeaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaa
abaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaa
ffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaadmcbabaaaabaaaaaagcbaaaad
pcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacacaaaaaaefaaaaaj
pcaabaaaaaaaaaaaogbkbaaaabaaaaaaeghobaaaaaaaaaaaaagabaaaabaaaaaa
diaaaaaibcaabaaaaaaaaaaaakaabaaaaaaaaaaabkiacaaaaaaaaaaaadaaaaaa
diaaaaahicaabaaaabaaaaaaakaabaaaaaaaaaaaakaabaaaaaaaaaaadiaaaaai
bcaabaaaaaaaaaaaakaabaaaaaaaaaaackiacaaaaaaaaaaaadaaaaaadcaaaaam
dcaabaaaaaaaaaaaagaabaaaaaaaaaaaaceaaaaaaknhcddmaknhkddlaaaaaaaa
aaaaaaaaegbabaaaabaaaaaaefaaaaajpcaabaaaaaaaaaaaegaabaaaaaaaaaaa
eghobaaaabaaaaaaaagabaaaaaaaaaaadiaaaaaipcaabaaaaaaaaaaaegaobaaa
aaaaaaaaagiacaaaaaaaaaaaabaaaaaadiaaaaaihcaabaaaabaaaaaapgapbaaa
abaaaaaaegiccaaaaaaaaaaaacaaaaaadiaaaaakpcaabaaaabaaaaaaegaobaaa
abaaaaaaaceaaaaaaaaaiaeaaaaaiaeaaaaaiaeaaaaaaaeadiaaaaaipcaabaaa
abaaaaaaegaobaaaabaaaaaaagiacaaaaaaaaaaaadaaaaaadcaaaaajpcaabaaa
abaaaaaaegaobaaaabaaaaaaegbobaaaacaaaaaaegaobaaaaaaaaaaadiaaaaah
pcaabaaaaaaaaaaapgapbaaaaaaaaaaaegaobaaaabaaaaaadiaaaaaihcaabaaa
abaaaaaaegacbaaaaaaaaaaapgipcaaaaaaaaaaaacaaaaaabaaaaaakbcaabaaa
abaaaaaaaceaaaaajkjjjjdodnakbhdpkoehobdnaaaaaaaaegacbaaaabaaaaaa
dcaaaaalhcaabaaaabaaaaaaegacbaiaebaaaaaaaaaaaaaapgipcaaaaaaaaaaa
acaaaaaaagaabaaaabaaaaaadiaaaaakhcaabaaaabaaaaaaegacbaaaabaaaaaa
aceaaaaadddddddpdddddddpdddddddpaaaaaaaadgaaaaaficaabaaaabaaaaaa
abeaaaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegaobaaaaaaaaaaapgipcaaa
aaaaaaaaacaaaaaaegaobaaaabaaaaaadicaaaakpccabaaaaaaaaaaaegaobaaa
aaaaaaaaaceaaaaajkjjjjdpjkjjjjdpjkjjnjdpddddlddpdoaaaaab"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_FxTex] 2D 1
SetTexture 1 [_MainTex] 2D 0
ConstBuffer "$Globals" 96
Float 16 [_TexIntensity]
Vector 32 [_Color]
Float 48 [_Intensity]
Float 52 [_FxIntensity]
Float 56 [_FxDistortion]
BindCB  "$Globals" 0
"ps_4_0_level_9_1
eefiecedchnkmkidlaplofipnfgfmgcdfoeadcddabaaaaaagaagaaaaaeaaaaaa
daaaaaaahaacaaaakaafaaaacmagaaaaebgpgodjdiacaaaadiacaaaaaaacpppp
aaacaaaadiaaaaaaabaacmaaaaaadiaaaaaadiaaacaaceaaaaaadiaaabaaaaaa
aaababaaaaaaabaaadaaaaaaaaaaaaaaaaacppppfbaaaaafadaaapkaaknhcddm
aknhkddldddddddpaaaaaaaafbaaaaafaeaaapkajkjjjjdodnakbhdpkoehobdn
aaaaaaaafbaaaaafafaaapkajkjjjjdpjkjjjjdpjkjjnjdpddddlddpfbaaaaaf
agaaapkaaaaaiaeaaaaaiaeaaaaaiaeaaaaaaaeabpaaaaacaaaaaaiaaaaaapla
bpaaaaacaaaaaaiaabaaaplabpaaaaacaaaaaajaaaaiapkabpaaaaacaaaaaaja
abaiapkaabaaaaacaaaaadiaaaaabllaecaaaaadaaaaapiaaaaaoeiaabaioeka
afaaaaadaaaacbiaaaaaaaiaacaaffkaafaaaaadabaaciiaaaaaaaiaaaaaaaia
afaaaaadaaaacbiaaaaaaaiaacaakkkaafaaaaadabaachiaabaappiaabaaoeka
afaaaaadabaaapiaabaaoeiaagaaoekaafaaaaadabaaapiaabaaoeiaacaaaaka
aeaaaaaeacaaabiaaaaaaaiaadaaaakaaaaaaalaaeaaaaaeacaaaciaaaaaaaia
adaaffkaaaaafflaecaaaaadaaaaapiaacaaoeiaaaaioekaafaaaaadaaaacpia
aaaaoeiaaaaaaakaaeaaaaaeabaaapiaabaaoeiaabaaoelaaaaaoeiaafaaaaad
aaaaapiaaaaappiaabaaoeiaafaaaaadabaachiaaaaaoeiaabaappkaaiaaaaad
abaacbiaaeaaoekaabaaoeiaaeaaaaaeabaachiaaaaaoeiaabaappkbabaaaaia
afaaaaadabaachiaabaaoeiaadaakkkaabaaaaacabaaciiaadaappkaaeaaaaae
aaaacpiaaaaaoeiaabaappkaabaaoeiaafaaaaadaaaadpiaaaaaoeiaafaaoeka
abaaaaacaaaicpiaaaaaoeiappppaaaafdeieefcciadaaaaeaaaaaaamkaaaaaa
fjaaaaaeegiocaaaaaaaaaaaaeaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaad
aagabaaaabaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaa
abaaaaaaffffaaaagcbaaaaddcbabaaaabaaaaaagcbaaaadmcbabaaaabaaaaaa
gcbaaaadpcbabaaaacaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacacaaaaaa
efaaaaajpcaabaaaaaaaaaaaogbkbaaaabaaaaaaeghobaaaaaaaaaaaaagabaaa
abaaaaaadiaaaaaibcaabaaaaaaaaaaaakaabaaaaaaaaaaabkiacaaaaaaaaaaa
adaaaaaadiaaaaahicaabaaaabaaaaaaakaabaaaaaaaaaaaakaabaaaaaaaaaaa
diaaaaaibcaabaaaaaaaaaaaakaabaaaaaaaaaaackiacaaaaaaaaaaaadaaaaaa
dcaaaaamdcaabaaaaaaaaaaaagaabaaaaaaaaaaaaceaaaaaaknhcddmaknhkddl
aaaaaaaaaaaaaaaaegbabaaaabaaaaaaefaaaaajpcaabaaaaaaaaaaaegaabaaa
aaaaaaaaeghobaaaabaaaaaaaagabaaaaaaaaaaadiaaaaaipcaabaaaaaaaaaaa
egaobaaaaaaaaaaaagiacaaaaaaaaaaaabaaaaaadiaaaaaihcaabaaaabaaaaaa
pgapbaaaabaaaaaaegiccaaaaaaaaaaaacaaaaaadiaaaaakpcaabaaaabaaaaaa
egaobaaaabaaaaaaaceaaaaaaaaaiaeaaaaaiaeaaaaaiaeaaaaaaaeadiaaaaai
pcaabaaaabaaaaaaegaobaaaabaaaaaaagiacaaaaaaaaaaaadaaaaaadcaaaaaj
pcaabaaaabaaaaaaegaobaaaabaaaaaaegbobaaaacaaaaaaegaobaaaaaaaaaaa
diaaaaahpcaabaaaaaaaaaaapgapbaaaaaaaaaaaegaobaaaabaaaaaadiaaaaai
hcaabaaaabaaaaaaegacbaaaaaaaaaaapgipcaaaaaaaaaaaacaaaaaabaaaaaak
bcaabaaaabaaaaaaaceaaaaajkjjjjdodnakbhdpkoehobdnaaaaaaaaegacbaaa
abaaaaaadcaaaaalhcaabaaaabaaaaaaegacbaiaebaaaaaaaaaaaaaapgipcaaa
aaaaaaaaacaaaaaaagaabaaaabaaaaaadiaaaaakhcaabaaaabaaaaaaegacbaaa
abaaaaaaaceaaaaadddddddpdddddddpdddddddpaaaaaaaadgaaaaaficaabaaa
abaaaaaaabeaaaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegaobaaaaaaaaaaa
pgipcaaaaaaaaaaaacaaaaaaegaobaaaabaaaaaadicaaaakpccabaaaaaaaaaaa
egaobaaaaaaaaaaaaceaaaaajkjjjjdpjkjjjjdpjkjjnjdpddddlddpdoaaaaab
ejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaa
aaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadadaaaa
heaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaaamamaaaahnaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfagphdgjhegjgpgoaafeeffied
epepfceeaaedepemepfcaaklepfdeheocmaaaaaaabaaaaaaaiaaaaaacaaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaafdfgfpfegbhcghgfheaaklkl
"
}
}
 }
}
Fallback Off
}