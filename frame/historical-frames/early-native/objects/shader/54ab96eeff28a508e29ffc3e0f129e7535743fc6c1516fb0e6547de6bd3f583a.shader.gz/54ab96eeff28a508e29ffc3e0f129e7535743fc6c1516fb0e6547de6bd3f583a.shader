Shader "Custom/Card/UnlitTextureReflection" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SpecTex ("Specular (RGB)", 2D) = "white" {}
 _ReflTex ("Reflection (RGB)", 2D) = "white" {}
 _ReflectionIntensity ("Reflection Intensity", Float) = 1
 _ReflectionColor ("Reflection Color", Color) = (0.8,0.8,0.8,1)
 _ReflectionFalloffColor ("Reflection Falloff Color", Color) = (0.3,0.3,0.3,1)
 _ReflectionFalloff ("Reflection Falloff", Float) = 2.5
 _ReflectionRotation ("Reflection Rotation", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="True" }
 Pass {
  Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="True" }
  BindChannels {
   Bind "color", Color
   Bind "normal", Normal
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
varying lowp vec4 xlv_COLOR1;
varying lowp vec4 xlv_COLOR;
uniform highp vec4 _MainTex_ST;
uniform mediump float _LightingBlend;
uniform mediump float _ReflectionRotation;
uniform mediump float _ReflectionFalloff;
uniform lowp vec4 _ReflectionFalloffColor;
uniform lowp vec4 _ReflectionColor;
uniform lowp vec4 _LightColor0;
uniform highp vec4 glstate_lightmodel_ambient;
uniform highp vec4 unity_Scale;
uniform highp mat4 _Object2World;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec3 _WorldSpaceCameraPos;
uniform highp vec4 _Time;
attribute vec4 _glesMultiTexCoord0;
attribute vec3 _glesNormal;
attribute vec4 _glesColor;
attribute vec4 _glesVertex;
void main ()
{
  mediump float falloff_1;
  mediump vec3 ws_2;
  lowp vec4 tmpvar_3;
  lowp vec4 tmpvar_4;
  highp vec2 tmpvar_5;
  highp vec2 tmpvar_6;
  tmpvar_6 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  mat3 tmpvar_7;
  tmpvar_7[0] = _Object2World[0].xyz;
  tmpvar_7[1] = _Object2World[1].xyz;
  tmpvar_7[2] = _Object2World[2].xyz;
  highp vec3 tmpvar_8;
  tmpvar_8 = ((tmpvar_7 * (normalize(_glesNormal) * unity_Scale.w)) * 0.3);
  highp vec3 tmpvar_9;
  tmpvar_9 = (_Object2World * _glesVertex).xyz;
  ws_2 = tmpvar_9;
  tmpvar_5 = (((-(tmpvar_6.x) * tmpvar_8) + ws_2) * 0.07).xz;
  tmpvar_5 = (tmpvar_5 + (_Time.x * _ReflectionRotation));
  highp float tmpvar_10;
  tmpvar_10 = abs(dot (normalize((_WorldSpaceCameraPos - (_Object2World * _glesVertex).xyz)), tmpvar_8));
  falloff_1 = tmpvar_10;
  mediump float tmpvar_11;
  tmpvar_11 = pow (falloff_1, _ReflectionFalloff);
  falloff_1 = tmpvar_11;
  mediump vec4 tmpvar_12;
  tmpvar_12 = mix (_ReflectionFalloffColor, _ReflectionColor, vec4(tmpvar_11));
  tmpvar_3 = tmpvar_12;
  highp vec4 tmpvar_13;
  tmpvar_13 = mix (_glesColor, ((_glesColor * (glstate_lightmodel_ambient * 2.0)) + _LightColor0), vec4(_LightingBlend));
  tmpvar_4 = tmpvar_13;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_COLOR = tmpvar_3;
  xlv_COLOR1 = tmpvar_4;
  xlv_TEXCOORD0 = tmpvar_6;
  xlv_TEXCOORD1 = tmpvar_5;
}



#endif
#ifdef FRAGMENT

varying highp vec2 xlv_TEXCOORD1;
varying highp vec2 xlv_TEXCOORD0;
varying lowp vec4 xlv_COLOR1;
varying lowp vec4 xlv_COLOR;
uniform mediump float _ReflectionIntensity;
uniform sampler2D _ReflTex;
uniform sampler2D _SpecTex;
uniform sampler2D _MainTex;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 mask_2;
  mediump vec4 col_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_SpecTex, xlv_TEXCOORD0);
  mask_2 = tmpvar_5;
  lowp vec4 tmpvar_6;
  highp vec2 P_7;
  P_7 = (xlv_TEXCOORD1 * 2.0);
  tmpvar_6 = texture2D (_ReflTex, P_7);
  mediump vec4 tmpvar_8;
  tmpvar_8 = (((tmpvar_6 * mask_2) * _ReflectionIntensity) * xlv_COLOR);
  tmpvar_1 = ((col_3 + tmpvar_8) * xlv_COLOR1);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback "Diffuse"
}