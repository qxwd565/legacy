Shader "Custom/Card/UnlitTextureReflection" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SpecTex ("Specular (RGB)", 2D) = "white" {}
 _ReflTex ("Reflection (RGB)", 2D) = "white" {}
 _ReflectionIntensity ("Reflection Intensity", Float) = 1
 _ReflectionColor ("Reflection Color", Color) = (0.8,0.8,0.8,1)
 _ReflectionFalloffColor ("Reflection Falloff Color", Color) = (0.3,0.3,0.3,1)
 _ReflectionFalloff ("Reflection Falloff", Float) = 2.5
 _ReflectionRotation ("Reflection Rotation", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="True" }
 Pass {
  Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="True" }
  BindChannels {
   Bind "color", Color
   Bind "normal", Normal
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
Matrix 5 [_Object2World]
Vector 2 [_Time]
Vector 3 [_WorldSpaceCameraPos]
Vector 4 [unity_Scale]
Vector 13 [_LightColor0]
Vector 14 [_ReflectionColor]
Vector 15 [_ReflectionFalloffColor]
Float 16 [_ReflectionFalloff]
Float 17 [_ReflectionRotation]
Float 18 [_LightingBlend]
Vector 19 [_MainTex_ST]
"!!ARBvp1.0
# 35 ALU
PARAM c[20] = { { 0.30000001, 2, 0.07 },
		state.lightmodel.ambient,
		program.local[2..8],
		state.matrix.mvp,
		program.local[13..19] };
TEMP R0;
TEMP R1;
TEMP R2;
TEMP R3;
DP4 R3.y, vertex.position, c[7];
DP4 R3.x, vertex.position, c[5];
MUL R2.xyz, vertex.normal, c[4].w;
MOV R0.z, R3.y;
MOV R0.x, R3;
DP4 R0.y, vertex.position, c[6];
ADD R1.xyz, -R0, c[3];
DP3 R0.x, R1, R1;
RSQ R0.w, R0.x;
DP3 R0.z, R2, c[7];
DP3 R0.x, R2, c[5];
DP3 R0.y, R2, c[6];
MAD R2.xy, vertex.texcoord[0], c[19], c[19].zwzw;
MUL R0.xyz, R0, c[0].x;
MUL R1.xyz, R0.w, R1;
DP3 R0.y, R1, R0;
MOV R1, c[15];
ABS R0.y, R0;
ADD R1, -R1, c[14];
POW R0.y, R0.y, c[16].x;
MAD result.color, R0.y, R1, c[15];
MAD R0.xy, R0.xzzw, -R2.x, R3;
MUL R1, vertex.color, c[1];
MUL R1, R1, c[0].y;
MOV R0.z, c[17].x;
ADD R1, R1, c[13];
MUL R0.z, R0, c[2].x;
ADD R1, R1, -vertex.color;
MAD result.texcoord[1].xy, R0, c[0].z, R0.z;
MAD result.color.secondary, R1, c[18].x, vertex.color;
MOV result.texcoord[0].xy, R2;
DP4 result.position.w, vertex.position, c[12];
DP4 result.position.z, vertex.position, c[11];
DP4 result.position.y, vertex.position, c[10];
DP4 result.position.x, vertex.position, c[9];
END
# 35 instructions, 4 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
Matrix 0 [glstate_matrix_mvp]
Matrix 4 [_Object2World]
Vector 8 [glstate_lightmodel_ambient]
Vector 9 [_Time]
Vector 10 [_WorldSpaceCameraPos]
Vector 11 [unity_Scale]
Vector 12 [_LightColor0]
Vector 13 [_ReflectionColor]
Vector 14 [_ReflectionFalloffColor]
Float 15 [_ReflectionFalloff]
Float 16 [_ReflectionRotation]
Float 17 [_LightingBlend]
Vector 18 [_MainTex_ST]
"vs_2_0
; 38 ALU
def c19, 0.30000001, 2.00000000, 0.07000000, 0
dcl_position0 v0
dcl_normal0 v1
dcl_texcoord0 v2
dcl_color0 v3
dp4 r3.y, v0, c6
dp4 r3.x, v0, c4
mul r2.xyz, v1, c11.w
mov r0.z, r3.y
mov r0.x, r3
dp4 r0.y, v0, c5
add r1.xyz, -r0, c10
dp3 r0.x, r1, r1
rsq r0.w, r0.x
dp3 r0.z, r2, c6
dp3 r0.x, r2, c4
dp3 r0.y, r2, c5
mov r2, c13
mul r0.xyz, r0, c19.x
mul r1.xyz, r0.w, r1
dp3 r0.y, r1, r0
abs r0.y, r0
pow r1, r0.y, c15.x
mov r0.y, r1.x
add r2, -c14, r2
mad oD0, r0.y, r2, c14
mad r2.xy, v2, c18, c18.zwzw
mad r0.xy, r0.xzzw, -r2.x, r3
mul r1, v3, c8
mul r1, r1, c19.y
mov r0.z, c9.x
add r1, r1, c12
mul r0.z, c16.x, r0
add r1, r1, -v3
mad oT1.xy, r0, c19.z, r0.z
mad oD1, r1, c17.x, v3
mov oT0.xy, r2
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Vector 48 [_ReflectionColor]
Vector 64 [_ReflectionFalloffColor]
Float 84 [_ReflectionFalloff]
Float 88 [_ReflectionRotation]
Float 92 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
Vector 64 [_WorldSpaceCameraPos] 3
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
Matrix 192 [_Object2World]
Vector 320 [unity_Scale]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
BindCB  "UnityPerFrame" 3
"vs_4_0
eefiecedidhkkmcpoihholepngikchcacipmehnlabaaaaaaomagaaaaadaaaaaa
cmaaaaaapeaaaaaajiabaaaaejfdeheomaaaaaaaagaaaaaaaiaaaaaajiaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaakbaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaapaaaaaakjaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaa
ahahaaaalaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaapadaaaalaaaaaaa
abaaaaaaaaaaaaaaadaaaaaaaeaaaaaaapaaaaaaljaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaafaaaaaaapapaaaafaepfdejfeejepeoaafeebeoehefeofeaaeoepfc
enebemaafeeffiedepepfceeaaedepemepfcaaklepfdeheojmaaaaaaafaaaaaa
aiaaaaaaiaaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaimaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaabaaaaaaapaaaaaaimaaaaaaabaaaaaaaaaaaaaa
adaaaaaaacaaaaaaapaaaaaajcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaa
adamaaaajcaaaaaaabaaaaaaaaaaaaaaadaaaaaaadaaaaaaamadaaaafdfgfpfa
gphdgjhegjgpgoaaedepemepfcaafeeffiedepepfceeaaklfdeieefcemafaaaa
eaaaabaafdabaaaafjaaaaaeegiocaaaaaaaaaaaahaaaaaafjaaaaaeegiocaaa
abaaaaaaafaaaaaafjaaaaaeegiocaaaacaaaaaabfaaaaaafjaaaaaeegiocaaa
adaaaaaaafaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaadhcbabaaaacaaaaaa
fpaaaaaddcbabaaaadaaaaaafpaaaaadpcbabaaaafaaaaaaghaaaaaepccabaaa
aaaaaaaaabaaaaaagfaaaaadpccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaa
gfaaaaaddccabaaaadaaaaaagfaaaaadmccabaaaadaaaaaagiaaaaacaeaaaaaa
diaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaacaaaaaaabaaaaaa
dcaaaaakpcaabaaaaaaaaaaaegiocaaaacaaaaaaaaaaaaaaagbabaaaaaaaaaaa
egaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaacaaaaaaacaaaaaa
kgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaa
acaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaadiaaaaaihcaabaaa
aaaaaaaafgbfbaaaaaaaaaaaegiccaaaacaaaaaaanaaaaaadcaaaaakhcaabaaa
aaaaaaaaegiccaaaacaaaaaaamaaaaaaagbabaaaaaaaaaaaegacbaaaaaaaaaaa
dcaaaaakhcaabaaaaaaaaaaaegiccaaaacaaaaaaaoaaaaaakgbkbaaaaaaaaaaa
egacbaaaaaaaaaaadcaaaaakhcaabaaaabaaaaaaegiccaaaacaaaaaaapaaaaaa
pgbpbaaaaaaaaaaaegacbaaaaaaaaaaadcaaaaakdcaabaaaaaaaaaaaigiacaaa
acaaaaaaapaaaaaapgbpbaaaaaaaaaaaigaabaaaaaaaaaaaaaaaaaajhcaabaaa
abaaaaaaegacbaiaebaaaaaaabaaaaaaegiccaaaabaaaaaaaeaaaaaabaaaaaah
ecaabaaaaaaaaaaaegacbaaaabaaaaaaegacbaaaabaaaaaaeeaaaaafecaabaaa
aaaaaaaackaabaaaaaaaaaaadiaaaaahhcaabaaaabaaaaaakgakbaaaaaaaaaaa
egacbaaaabaaaaaadiaaaaaihcaabaaaacaaaaaaegbcbaaaacaaaaaapgipcaaa
acaaaaaabeaaaaaadiaaaaaihcaabaaaadaaaaaafgafbaaaacaaaaaaegiccaaa
acaaaaaaanaaaaaadcaaaaaklcaabaaaacaaaaaaegiicaaaacaaaaaaamaaaaaa
agaabaaaacaaaaaaegaibaaaadaaaaaadcaaaaakhcaabaaaacaaaaaaegiccaaa
acaaaaaaaoaaaaaakgakbaaaacaaaaaaegadbaaaacaaaaaadiaaaaakhcaabaaa
acaaaaaaegacbaaaacaaaaaaaceaaaaajkjjjjdojkjjjjdojkjjjjdoaaaaaaaa
baaaaaahecaabaaaaaaaaaaaegacbaaaabaaaaaaegacbaaaacaaaaaacpaaaaag
ecaabaaaaaaaaaaackaabaiaibaaaaaaaaaaaaaadiaaaaaiecaabaaaaaaaaaaa
ckaabaaaaaaaaaaabkiacaaaaaaaaaaaafaaaaaabjaaaaafecaabaaaaaaaaaaa
ckaabaaaaaaaaaaaaaaaaaakpcaabaaaabaaaaaaegiocaaaaaaaaaaaadaaaaaa
egiocaiaebaaaaaaaaaaaaaaaeaaaaaadcaaaaakpccabaaaabaaaaaakgakbaaa
aaaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaaaeaaaaaaaaaaaaajpcaabaaa
abaaaaaaegiocaaaadaaaaaaaeaaaaaaegiocaaaadaaaaaaaeaaaaaadcaaaaak
pcaabaaaabaaaaaaegbobaaaafaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaa
abaaaaaaaaaaaaaipcaabaaaabaaaaaaegaobaaaabaaaaaaegbobaiaebaaaaaa
afaaaaaadcaaaaakpccabaaaacaaaaaapgipcaaaaaaaaaaaafaaaaaaegaobaaa
abaaaaaaegbobaaaafaaaaaadcaaaaalmcaabaaaaaaaaaaaagbebaaaadaaaaaa
agiecaaaaaaaaaaaagaaaaaakgiocaaaaaaaaaaaagaaaaaadcaaaaakdcaabaaa
aaaaaaaakgakbaiaebaaaaaaaaaaaaaaigaabaaaacaaaaaaegaabaaaaaaaaaaa
dgaaaaafdccabaaaadaaaaaaogakbaaaaaaaaaaadiaaaaajecaabaaaaaaaaaaa
ckiacaaaaaaaaaaaafaaaaaaakiacaaaabaaaaaaaaaaaaaadcaaaaammccabaaa
adaaaaaaagaebaaaaaaaaaaaaceaaaaaaaaaaaaaaaaaaaaacjfmipdncjfmipdn
kgakbaaaaaaaaaaadoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "color" Color
Bind "normal" Normal
Bind "texcoord" TexCoord0
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Vector 48 [_ReflectionColor]
Vector 64 [_ReflectionFalloffColor]
Float 84 [_ReflectionFalloff]
Float 88 [_ReflectionRotation]
Float 92 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
Vector 64 [_WorldSpaceCameraPos] 3
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
Matrix 192 [_Object2World]
Vector 320 [unity_Scale]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
BindCB  "UnityPerDraw" 2
BindCB  "UnityPerFrame" 3
"vs_4_0_level_9_1
eefiecedeekohagcbikmpflbagpklognnmggbcgaabaaaaaacmakaaaaaeaaaaaa
daaaaaaagmadaaaamaaiaaaaiiajaaaaebgpgodjdeadaaaadeadaaaaaaacpopp
kmacaaaaiiaaaaaaaiaaceaaaaaaieaaaaaaieaaaaaaceaaabaaieaaaaaaabaa
abaaabaaaaaaaaaaaaaaadaaaeaaacaaaaaaaaaaabaaaaaaabaaagaaaaaaaaaa
abaaaeaaabaaahaaaaaaaaaaacaaaaaaaeaaaiaaaaaaaaaaacaaamaaaeaaamaa
aaaaaaaaacaabeaaabaabaaaaaaaaaaaadaaaeaaabaabbaaaaaaaaaaaaaaaaaa
aaacpoppfbaaaaafbcaaapkajkjjjjdocjfmipdnaaaaaaeaaaaaaaaabpaaaaac
afaaaaiaaaaaapjabpaaaaacafaaaciaacaaapjabpaaaaacafaaadiaadaaapja
bpaaaaacafaaafiaafaaapjaafaaaaadaaaaahiaacaaoejabaaappkaafaaaaad
abaaahiaaaaaffiaanaaoekaaeaaaaaeaaaaaliaamaakekaaaaaaaiaabaakeia
aeaaaaaeaaaaahiaaoaaoekaaaaakkiaaaaapeiaafaaaaadaaaaahiaaaaaoeia
bcaaaakaafaaaaadabaaahiaaaaaffjaanaaoekaaeaaaaaeabaaahiaamaaoeka
aaaaaajaabaaoeiaaeaaaaaeabaaahiaaoaaoekaaaaakkjaabaaoeiaaeaaaaae
acaaadiaapaaockaaaaappjaabaaociaaeaaaaaeabaaahiaapaaoekaaaaappja
abaaoeiaacaaaaadabaaahiaabaaoeibahaaoekaceaaaaacadaaahiaabaaoeia
aiaaaaadaaaaaciaadaaoeiaaaaaoeiacdaaaaacabaaadiaaaaaffiaaeaaaaae
aaaaakiaadaagajaafaagakaafaaoikaaeaaaaaeaaaaafiaaaaaffibaaaamgia
acaaneiaabaaaaacacaaadoaaaaaoniaabaaaaacacaaaeiaaeaakkkaafaaaaad
aaaaaciaacaakkiaagaaaakaaeaaaaaeacaaamoaaaaaieiabcaaffkaaaaaffia
abaaaaacabaaamiaaeaaffkabaaaaaacaaaaapiaabaaoeiaabaaaaacabaaapia
adaaoekaacaaaaadabaaapiaabaaoeibacaaoekaaeaaaaaeaaaaapoaaaaakkia
abaaoeiaadaaoekaafaaaaadaaaaapiaafaaoejabbaaoekaabaaaaacabaaaeia
bcaakkkaaeaaaaaeaaaaapiaaaaaoeiaabaakkiaabaaoekaacaaaaadaaaaapia
aaaaoeiaafaaoejbaeaaaaaeabaaapoaaeaappkaaaaaoeiaafaaoejaafaaaaad
aaaaapiaaaaaffjaajaaoekaaeaaaaaeaaaaapiaaiaaoekaaaaaaajaaaaaoeia
aeaaaaaeaaaaapiaakaaoekaaaaakkjaaaaaoeiaaeaaaaaeaaaaapiaalaaoeka
aaaappjaaaaaoeiaaeaaaaaeaaaaadmaaaaappiaaaaaoekaaaaaoeiaabaaaaac
aaaaammaaaaaoeiappppaaaafdeieefcemafaaaaeaaaabaafdabaaaafjaaaaae
egiocaaaaaaaaaaaahaaaaaafjaaaaaeegiocaaaabaaaaaaafaaaaaafjaaaaae
egiocaaaacaaaaaabfaaaaaafjaaaaaeegiocaaaadaaaaaaafaaaaaafpaaaaad
pcbabaaaaaaaaaaafpaaaaadhcbabaaaacaaaaaafpaaaaaddcbabaaaadaaaaaa
fpaaaaadpcbabaaaafaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaad
pccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaagfaaaaaddccabaaaadaaaaaa
gfaaaaadmccabaaaadaaaaaagiaaaaacaeaaaaaadiaaaaaipcaabaaaaaaaaaaa
fgbfbaaaaaaaaaaaegiocaaaacaaaaaaabaaaaaadcaaaaakpcaabaaaaaaaaaaa
egiocaaaacaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaak
pcaabaaaaaaaaaaaegiocaaaacaaaaaaacaaaaaakgbkbaaaaaaaaaaaegaobaaa
aaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaacaaaaaaadaaaaaapgbpbaaa
aaaaaaaaegaobaaaaaaaaaaadiaaaaaihcaabaaaaaaaaaaafgbfbaaaaaaaaaaa
egiccaaaacaaaaaaanaaaaaadcaaaaakhcaabaaaaaaaaaaaegiccaaaacaaaaaa
amaaaaaaagbabaaaaaaaaaaaegacbaaaaaaaaaaadcaaaaakhcaabaaaaaaaaaaa
egiccaaaacaaaaaaaoaaaaaakgbkbaaaaaaaaaaaegacbaaaaaaaaaaadcaaaaak
hcaabaaaabaaaaaaegiccaaaacaaaaaaapaaaaaapgbpbaaaaaaaaaaaegacbaaa
aaaaaaaadcaaaaakdcaabaaaaaaaaaaaigiacaaaacaaaaaaapaaaaaapgbpbaaa
aaaaaaaaigaabaaaaaaaaaaaaaaaaaajhcaabaaaabaaaaaaegacbaiaebaaaaaa
abaaaaaaegiccaaaabaaaaaaaeaaaaaabaaaaaahecaabaaaaaaaaaaaegacbaaa
abaaaaaaegacbaaaabaaaaaaeeaaaaafecaabaaaaaaaaaaackaabaaaaaaaaaaa
diaaaaahhcaabaaaabaaaaaakgakbaaaaaaaaaaaegacbaaaabaaaaaadiaaaaai
hcaabaaaacaaaaaaegbcbaaaacaaaaaapgipcaaaacaaaaaabeaaaaaadiaaaaai
hcaabaaaadaaaaaafgafbaaaacaaaaaaegiccaaaacaaaaaaanaaaaaadcaaaaak
lcaabaaaacaaaaaaegiicaaaacaaaaaaamaaaaaaagaabaaaacaaaaaaegaibaaa
adaaaaaadcaaaaakhcaabaaaacaaaaaaegiccaaaacaaaaaaaoaaaaaakgakbaaa
acaaaaaaegadbaaaacaaaaaadiaaaaakhcaabaaaacaaaaaaegacbaaaacaaaaaa
aceaaaaajkjjjjdojkjjjjdojkjjjjdoaaaaaaaabaaaaaahecaabaaaaaaaaaaa
egacbaaaabaaaaaaegacbaaaacaaaaaacpaaaaagecaabaaaaaaaaaaackaabaia
ibaaaaaaaaaaaaaadiaaaaaiecaabaaaaaaaaaaackaabaaaaaaaaaaabkiacaaa
aaaaaaaaafaaaaaabjaaaaafecaabaaaaaaaaaaackaabaaaaaaaaaaaaaaaaaak
pcaabaaaabaaaaaaegiocaaaaaaaaaaaadaaaaaaegiocaiaebaaaaaaaaaaaaaa
aeaaaaaadcaaaaakpccabaaaabaaaaaakgakbaaaaaaaaaaaegaobaaaabaaaaaa
egiocaaaaaaaaaaaaeaaaaaaaaaaaaajpcaabaaaabaaaaaaegiocaaaadaaaaaa
aeaaaaaaegiocaaaadaaaaaaaeaaaaaadcaaaaakpcaabaaaabaaaaaaegbobaaa
afaaaaaaegaobaaaabaaaaaaegiocaaaaaaaaaaaabaaaaaaaaaaaaaipcaabaaa
abaaaaaaegaobaaaabaaaaaaegbobaiaebaaaaaaafaaaaaadcaaaaakpccabaaa
acaaaaaapgipcaaaaaaaaaaaafaaaaaaegaobaaaabaaaaaaegbobaaaafaaaaaa
dcaaaaalmcaabaaaaaaaaaaaagbebaaaadaaaaaaagiecaaaaaaaaaaaagaaaaaa
kgiocaaaaaaaaaaaagaaaaaadcaaaaakdcaabaaaaaaaaaaakgakbaiaebaaaaaa
aaaaaaaaigaabaaaacaaaaaaegaabaaaaaaaaaaadgaaaaafdccabaaaadaaaaaa
ogakbaaaaaaaaaaadiaaaaajecaabaaaaaaaaaaackiacaaaaaaaaaaaafaaaaaa
akiacaaaabaaaaaaaaaaaaaadcaaaaammccabaaaadaaaaaaagaebaaaaaaaaaaa
aceaaaaaaaaaaaaaaaaaaaaacjfmipdncjfmipdnkgakbaaaaaaaaaaadoaaaaab
ejfdeheomaaaaaaaagaaaaaaaiaaaaaajiaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
aaaaaaaaapapaaaakbaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaapaaaaaa
kjaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaahahaaaalaaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaadaaaaaaapadaaaalaaaaaaaabaaaaaaaaaaaaaaadaaaaaa
aeaaaaaaapaaaaaaljaaaaaaaaaaaaaaaaaaaaaaadaaaaaaafaaaaaaapapaaaa
faepfdejfeejepeoaafeebeoehefeofeaaeoepfcenebemaafeeffiedepepfcee
aaedepemepfcaaklepfdeheojmaaaaaaafaaaaaaaiaaaaaaiaaaaaaaaaaaaaaa
abaaaaaaadaaaaaaaaaaaaaaapaaaaaaimaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
abaaaaaaapaaaaaaimaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaaapaaaaaa
jcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaadamaaaajcaaaaaaabaaaaaa
aaaaaaaaadaaaaaaadaaaaaaamadaaaafdfgfpfagphdgjhegjgpgoaaedepemep
fcaafeeffiedepepfceeaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Float 0 [_ReflectionIntensity]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 9 ALU, 3 TEX
PARAM c[2] = { program.local[0],
		{ 2 } };
TEMP R0;
TEMP R1;
TEMP R2;
TEX R0, fragment.texcoord[0], texture[0], 2D;
TEX R2, fragment.texcoord[0], texture[1], 2D;
MUL R1.xy, fragment.texcoord[1], c[1].x;
TEX R1, R1, texture[2], 2D;
MUL R1, R1, R2;
MUL R1, R1, c[0].x;
MUL R1, R1, fragment.color.primary;
ADD R0, R0, R1;
MUL result.color, R0, fragment.color.secondary;
END
# 9 instructions, 3 R-regs
"
}
SubProgram "d3d9 " {
Float 0 [_ReflectionIntensity]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
"ps_2_0
; 7 ALU, 3 TEX
dcl_2d s0
dcl_2d s1
dcl_2d s2
def c1, 2.00000000, 0, 0, 0
dcl v0
dcl v1
dcl t0.xy
dcl t1.xy
texld r2, t0, s0
texld r1, t0, s1
mul r0.xy, t1, c1.x
texld r0, r0, s2
mul r0, r0, r1
mul r0, r0, c0.x
mul r0, r0, v0
add_pp r0, r2, r0
mul_pp r0, r0, v1
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
ConstBuffer "$Globals" 112
Float 80 [_ReflectionIntensity]
BindCB  "$Globals" 0
"ps_4_0
eefiecedpifmeklglfbcmhpbiikjhogijbpcigniabaaaaaameacaaaaadaaaaaa
cmaaaaaanaaaaaaaaeabaaaaejfdeheojmaaaaaaafaaaaaaaiaaaaaaiaaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaimaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaapapaaaaimaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaa
apapaaaajcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaaadadaaaajcaaaaaa
abaaaaaaaaaaaaaaadaaaaaaadaaaaaaamamaaaafdfgfpfagphdgjhegjgpgoaa
edepemepfcaafeeffiedepepfceeaaklepfdeheocmaaaaaaabaaaaaaaiaaaaaa
caaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaafdfgfpfegbhcghgf
heaaklklfdeieefcliabaaaaeaaaaaaagoaaaaaafjaaaaaeegiocaaaaaaaaaaa
agaaaaaafkaaaaadaagabaaaaaaaaaaafkaaaaadaagabaaaabaaaaaafkaaaaad
aagabaaaacaaaaaafibiaaaeaahabaaaaaaaaaaaffffaaaafibiaaaeaahabaaa
abaaaaaaffffaaaafibiaaaeaahabaaaacaaaaaaffffaaaagcbaaaadpcbabaaa
abaaaaaagcbaaaadpcbabaaaacaaaaaagcbaaaaddcbabaaaadaaaaaagcbaaaad
mcbabaaaadaaaaaagfaaaaadpccabaaaaaaaaaaagiaaaaacacaaaaaaaaaaaaah
dcaabaaaaaaaaaaaogbkbaaaadaaaaaaogbkbaaaadaaaaaaefaaaaajpcaabaaa
aaaaaaaaegaabaaaaaaaaaaaeghobaaaacaaaaaaaagabaaaacaaaaaaefaaaaaj
pcaabaaaabaaaaaaegbabaaaadaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaa
diaaaaahpcaabaaaaaaaaaaaegaobaaaaaaaaaaaegaobaaaabaaaaaadiaaaaai
pcaabaaaaaaaaaaaegaobaaaaaaaaaaaagiacaaaaaaaaaaaafaaaaaaefaaaaaj
pcaabaaaabaaaaaaegbabaaaadaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaa
dcaaaaajpcaabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaaaabaaaaaaegaobaaa
abaaaaaadiaaaaahpccabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaa
doaaaaab"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
ConstBuffer "$Globals" 112
Float 80 [_ReflectionIntensity]
BindCB  "$Globals" 0
"ps_4_0_level_9_1
eefiecedifabooniendafhfjpmkjieilfdbhgpeoabaaaaaaomadaaaaaeaaaaaa
daaaaaaafeabaaaabeadaaaaliadaaaaebgpgodjbmabaaaabmabaaaaaaacpppp
oaaaaaaadmaaaaaaabaadaaaaaaadmaaaaaadmaaadaaceaaaaaadmaaaaaaaaaa
abababaaacacacaaaaaaafaaabaaaaaaaaaaaaaaaaacppppbpaaaaacaaaaaaia
aaaaaplabpaaaaacaaaaaaiaabaacplabpaaaaacaaaaaaiaacaaaplabpaaaaac
aaaaaajaaaaiapkabpaaaaacaaaaaajaabaiapkabpaaaaacaaaaaajaacaiapka
acaaaaadaaaaadiaacaabllaacaabllaecaaaaadaaaaapiaaaaaoeiaacaioeka
ecaaaaadabaacpiaacaaoelaabaioekaecaaaaadacaacpiaacaaoelaaaaioeka
afaaaaadaaaaapiaaaaaoeiaabaaoeiaafaaaaadaaaaapiaaaaaoeiaaaaaaaka
aeaaaaaeaaaacpiaaaaaoeiaaaaaoelaacaaoeiaafaaaaadaaaacpiaaaaaoeia
abaaoelaabaaaaacaaaicpiaaaaaoeiappppaaaafdeieefcliabaaaaeaaaaaaa
goaaaaaafjaaaaaeegiocaaaaaaaaaaaagaaaaaafkaaaaadaagabaaaaaaaaaaa
fkaaaaadaagabaaaabaaaaaafkaaaaadaagabaaaacaaaaaafibiaaaeaahabaaa
aaaaaaaaffffaaaafibiaaaeaahabaaaabaaaaaaffffaaaafibiaaaeaahabaaa
acaaaaaaffffaaaagcbaaaadpcbabaaaabaaaaaagcbaaaadpcbabaaaacaaaaaa
gcbaaaaddcbabaaaadaaaaaagcbaaaadmcbabaaaadaaaaaagfaaaaadpccabaaa
aaaaaaaagiaaaaacacaaaaaaaaaaaaahdcaabaaaaaaaaaaaogbkbaaaadaaaaaa
ogbkbaaaadaaaaaaefaaaaajpcaabaaaaaaaaaaaegaabaaaaaaaaaaaeghobaaa
acaaaaaaaagabaaaacaaaaaaefaaaaajpcaabaaaabaaaaaaegbabaaaadaaaaaa
eghobaaaabaaaaaaaagabaaaabaaaaaadiaaaaahpcaabaaaaaaaaaaaegaobaaa
aaaaaaaaegaobaaaabaaaaaadiaaaaaipcaabaaaaaaaaaaaegaobaaaaaaaaaaa
agiacaaaaaaaaaaaafaaaaaaefaaaaajpcaabaaaabaaaaaaegbabaaaadaaaaaa
eghobaaaaaaaaaaaaagabaaaaaaaaaaadcaaaaajpcaabaaaaaaaaaaaegaobaaa
aaaaaaaaegbobaaaabaaaaaaegaobaaaabaaaaaadiaaaaahpccabaaaaaaaaaaa
egaobaaaaaaaaaaaegbobaaaacaaaaaadoaaaaabejfdeheojmaaaaaaafaaaaaa
aiaaaaaaiaaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaimaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaabaaaaaaapapaaaaimaaaaaaabaaaaaaaaaaaaaa
adaaaaaaacaaaaaaapapaaaajcaaaaaaaaaaaaaaaaaaaaaaadaaaaaaadaaaaaa
adadaaaajcaaaaaaabaaaaaaaaaaaaaaadaaaaaaadaaaaaaamamaaaafdfgfpfa
gphdgjhegjgpgoaaedepemepfcaafeeffiedepepfceeaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklkl"
}
}
 }
}
Fallback "Diffuse"
}