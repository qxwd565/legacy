Shader "Hero/DiffuseAlphaMaskScroller" {
Properties {
 _MainTex ("_MainTex", 2D) = "black" {}
 _ScrollingTex ("_ScrollingTex", 2D) = "black" {}
 _tint ("_tint", Color) = (1,1,1,1)
 _Fade ("_Fade", Color) = (1,1,1,1)
 _YSpeed ("_YSpeed", Float) = 0.1
 _XSpeed ("_XSpeed", Float) = 0.1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" }
 Pass {
  Tags { "RenderType"="Opaque" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "texcoord", TexCoord
   Bind "texcoord1", TexCoord1
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "opengl " {
Bind "vertex" Vertex
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
Vector 6 [_LightColor0]
Float 7 [_LightingBlend]
Vector 8 [_MainTex_ST]
"!!ARBvp1.0
# 12 ALU
PARAM c[9] = { { 2, 1 },
		state.lightmodel.ambient,
		state.matrix.mvp,
		program.local[6..8] };
TEMP R0;
TEMP R1;
MOV R0.x, c[0];
MUL R0, R0.x, c[1];
ADD R1, R0, c[6];
MOV R0.x, c[0].y;
ADD R1, R1, -c[0].y;
MAD result.color, R1, c[7].x, R0.x;
MAD result.texcoord[0].xy, vertex.texcoord[0], c[8], c[8].zwzw;
MAD result.texcoord[1].xy, vertex.texcoord[1], c[8], c[8].zwzw;
DP4 result.position.w, vertex.position, c[5];
DP4 result.position.z, vertex.position, c[4];
DP4 result.position.y, vertex.position, c[3];
DP4 result.position.x, vertex.position, c[2];
END
# 12 instructions, 2 R-regs
"
}
SubProgram "d3d9 " {
Bind "vertex" Vertex
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
Matrix 0 [glstate_matrix_mvp]
Vector 4 [glstate_lightmodel_ambient]
Vector 5 [_LightColor0]
Float 6 [_LightingBlend]
Vector 7 [_MainTex_ST]
"vs_2_0
; 12 ALU
def c8, 2.00000000, -1.00000000, 1.00000000, 0
dcl_position0 v0
dcl_texcoord0 v1
dcl_texcoord1 v2
mov r0, c4
mul r0, c8.x, r0
add r1, r0, c5
mov r0.x, c8.z
add r1, r1, c8.y
mad oD0, r1, c6.x, r0.x
mad oT0.xy, v1, c7, c7.zwzw
mad oT1.xy, v2, c7, c7.zwzw
dp4 oPos.w, v0, c3
dp4 oPos.z, v0, c2
dp4 oPos.y, v0, c1
dp4 oPos.x, v0, c0
"
}
SubProgram "d3d11 " {
Bind "vertex" Vertex
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Float 88 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
BindCB  "UnityPerFrame" 2
"vs_4_0
eefieceddfbkjnbkgjjgflnekkhnlhccjdhllpkaabaaaaaaemadaaaaadaaaaaa
cmaaaaaajiaaaaaaceabaaaaejfdeheogeaaaaaaadaaaaaaaiaaaaaafaaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaafjaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaa
adadaaaafaepfdejfeejepeoaafeeffiedepepfceeaaklklepfdeheoieaaaaaa
aeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaa
heaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaa
aaaaaaaaadaaaaaaabaaaaaaamadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
acaaaaaaapaaaaaafdfgfpfagphdgjhegjgpgoaafeeffiedepepfceeaaedepem
epfcaaklfdeieefccaacaaaaeaaaabaaiiaaaaaafjaaaaaeegiocaaaaaaaaaaa
ahaaaaaafjaaaaaeegiocaaaabaaaaaaaeaaaaaafjaaaaaeegiocaaaacaaaaaa
afaaaaaafpaaaaadpcbabaaaaaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaad
dcbabaaaacaaaaaaghaaaaaepccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaa
abaaaaaagfaaaaadmccabaaaabaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaac
abaaaaaadiaaaaaipcaabaaaaaaaaaaafgbfbaaaaaaaaaaaegiocaaaabaaaaaa
abaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaaaaaaaaaagbabaaa
aaaaaaaaegaobaaaaaaaaaaadcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaa
acaaaaaakgbkbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaa
egiocaaaabaaaaaaadaaaaaapgbpbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaal
dccabaaaabaaaaaaegbabaaaabaaaaaaegiacaaaaaaaaaaaagaaaaaaogikcaaa
aaaaaaaaagaaaaaadcaaaaalmccabaaaabaaaaaaagbebaaaacaaaaaaagiecaaa
aaaaaaaaagaaaaaakgiocaaaaaaaaaaaagaaaaaadcaaaaaopcaabaaaaaaaaaaa
egiocaaaacaaaaaaaeaaaaaaaceaaaaaaaaaaaeaaaaaaaeaaaaaaaeaaaaaaaea
egiocaaaaaaaaaaaabaaaaaaaaaaaaakpcaabaaaaaaaaaaaegaobaaaaaaaaaaa
aceaaaaaaaaaialpaaaaialpaaaaialpaaaaialpdcaaaaanpccabaaaacaaaaaa
kgikcaaaaaaaaaaaafaaaaaaegaobaaaaaaaaaaaaceaaaaaaaaaiadpaaaaiadp
aaaaiadpaaaaiadpdoaaaaab"
}
SubProgram "d3d11_9x " {
Bind "vertex" Vertex
Bind "texcoord" TexCoord0
Bind "texcoord1" TexCoord1
ConstBuffer "$Globals" 112
Vector 16 [_LightColor0]
Float 88 [_LightingBlend]
Vector 96 [_MainTex_ST]
ConstBuffer "UnityPerDraw" 336
Matrix 0 [glstate_matrix_mvp]
ConstBuffer "UnityPerFrame" 208
Vector 64 [glstate_lightmodel_ambient]
BindCB  "$Globals" 0
BindCB  "UnityPerDraw" 1
BindCB  "UnityPerFrame" 2
"vs_4_0_level_9_1
eefiecedhpjcakpibafkdbhanffdjdecliiagbnaabaaaaaaniaeaaaaaeaaaaaa
daaaaaaaliabaaaaoaadaaaaemaeaaaaebgpgodjiaabaaaaiaabaaaaaaacpopp
ciabaaaafiaaaaaaaeaaceaaaaaafeaaaaaafeaaaaaaceaaabaafeaaaaaaabaa
abaaabaaaaaaaaaaaaaaafaaacaaacaaaaaaaaaaabaaaaaaaeaaaeaaaaaaaaaa
acaaaeaaabaaaiaaaaaaaaaaaaaaaaaaaaacpoppfbaaaaafajaaapkaaaaaaaea
aaaaialpaaaaiadpaaaaaaaabpaaaaacafaaaaiaaaaaapjabpaaaaacafaaabia
abaaapjabpaaaaacafaaaciaacaaapjaaeaaaaaeaaaaadoaabaaoejaadaaoeka
adaaookaaeaaaaaeaaaaamoaacaabejaadaabekaadaalekaabaaaaacaaaaafia
ajaaoekaabaaaaacabaaapiaaiaaoekaaeaaaaaeabaaapiaabaaoeiaaaaaaaia
abaaoekaacaaaaadabaaapiaabaaoeiaajaaffkaaeaaaaaeabaaapoaacaakkka
abaaoeiaaaaakkiaafaaaaadaaaaapiaaaaaffjaafaaoekaaeaaaaaeaaaaapia
aeaaoekaaaaaaajaaaaaoeiaaeaaaaaeaaaaapiaagaaoekaaaaakkjaaaaaoeia
aeaaaaaeaaaaapiaahaaoekaaaaappjaaaaaoeiaaeaaaaaeaaaaadmaaaaappia
aaaaoekaaaaaoeiaabaaaaacaaaaammaaaaaoeiappppaaaafdeieefccaacaaaa
eaaaabaaiiaaaaaafjaaaaaeegiocaaaaaaaaaaaahaaaaaafjaaaaaeegiocaaa
abaaaaaaaeaaaaaafjaaaaaeegiocaaaacaaaaaaafaaaaaafpaaaaadpcbabaaa
aaaaaaaafpaaaaaddcbabaaaabaaaaaafpaaaaaddcbabaaaacaaaaaaghaaaaae
pccabaaaaaaaaaaaabaaaaaagfaaaaaddccabaaaabaaaaaagfaaaaadmccabaaa
abaaaaaagfaaaaadpccabaaaacaaaaaagiaaaaacabaaaaaadiaaaaaipcaabaaa
aaaaaaaafgbfbaaaaaaaaaaaegiocaaaabaaaaaaabaaaaaadcaaaaakpcaabaaa
aaaaaaaaegiocaaaabaaaaaaaaaaaaaaagbabaaaaaaaaaaaegaobaaaaaaaaaaa
dcaaaaakpcaabaaaaaaaaaaaegiocaaaabaaaaaaacaaaaaakgbkbaaaaaaaaaaa
egaobaaaaaaaaaaadcaaaaakpccabaaaaaaaaaaaegiocaaaabaaaaaaadaaaaaa
pgbpbaaaaaaaaaaaegaobaaaaaaaaaaadcaaaaaldccabaaaabaaaaaaegbabaaa
abaaaaaaegiacaaaaaaaaaaaagaaaaaaogikcaaaaaaaaaaaagaaaaaadcaaaaal
mccabaaaabaaaaaaagbebaaaacaaaaaaagiecaaaaaaaaaaaagaaaaaakgiocaaa
aaaaaaaaagaaaaaadcaaaaaopcaabaaaaaaaaaaaegiocaaaacaaaaaaaeaaaaaa
aceaaaaaaaaaaaeaaaaaaaeaaaaaaaeaaaaaaaeaegiocaaaaaaaaaaaabaaaaaa
aaaaaaakpcaabaaaaaaaaaaaegaobaaaaaaaaaaaaceaaaaaaaaaialpaaaaialp
aaaaialpaaaaialpdcaaaaanpccabaaaacaaaaaakgikcaaaaaaaaaaaafaaaaaa
egaobaaaaaaaaaaaaceaaaaaaaaaiadpaaaaiadpaaaaiadpaaaaiadpdoaaaaab
ejfdeheogeaaaaaaadaaaaaaaiaaaaaafaaaaaaaaaaaaaaaaaaaaaaaadaaaaaa
aaaaaaaaapapaaaafjaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadadaaaa
fjaaaaaaabaaaaaaaaaaaaaaadaaaaaaacaaaaaaadadaaaafaepfdejfeejepeo
aafeeffiedepepfceeaaklklepfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadamaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amadaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapaaaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaakl"
}
}
Program "fp" {
SubProgram "opengl " {
Vector 0 [_Time]
Vector 1 [_tint]
Vector 2 [_Fade]
Float 3 [_YSpeed]
Float 4 [_XSpeed]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_ScrollingTex] 2D 1
"!!ARBfp1.0
OPTION ARB_precision_hint_fastest;
# 12 ALU, 2 TEX
PARAM c[6] = { program.local[0..4],
		{ 1.5, 1 } };
TEMP R0;
TEMP R1;
MOV R0.y, c[3].x;
MOV R0.x, c[4];
MAD R0.y, R0, c[0].x, fragment.texcoord[1];
MAD R0.x, R0, c[0], fragment.texcoord[1];
TEX R1.x, R0, texture[1], 2D;
TEX R0, fragment.texcoord[0], texture[0], 2D;
MUL R1.xyz, R1.x, c[1];
MUL R1.xyz, R1, R0.w;
MAD R0.xyz, R1, c[5].x, R0;
MOV R0.w, c[5].y;
MUL R0.xyz, R0, c[2];
MUL result.color, R0, fragment.color.primary;
END
# 12 instructions, 2 R-regs
"
}
SubProgram "d3d9 " {
Vector 0 [_Time]
Vector 1 [_tint]
Vector 2 [_Fade]
Float 3 [_YSpeed]
Float 4 [_XSpeed]
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_ScrollingTex] 2D 1
"ps_2_0
; 11 ALU, 2 TEX
dcl_2d s0
dcl_2d s1
def c5, 1.50000000, 1.00000000, 0, 0
dcl t0.xy
dcl t1.xy
dcl v0
mov r1.x, c0
mov r0.x, c0
mad r0.y, c3.x, r1.x, t1
mad r0.x, c4, r0, t1
texld r1, r0, s1
texld r0, t0, s0
mul_pp r1.xyz, r1.x, c1
mul_pp r1.xyz, r1, r0.w
mad_pp r0.xyz, r1, c5.x, r0
mov_pp r0.w, c5.y
mul_pp r0.xyz, r0, c2
mul_pp r0, r0, v0
mov_pp oC0, r0
"
}
SubProgram "d3d11 " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_ScrollingTex] 2D 1
ConstBuffer "$Globals" 112
Vector 48 [_tint]
Vector 64 [_Fade]
Float 80 [_YSpeed]
Float 84 [_XSpeed]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
"ps_4_0
eefieceddaenohbdppabaocgmkhjkdedmmlpchlgabaaaaaamaacaaaaadaaaaaa
cmaaaaaaliaaaaaaomaaaaaaejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaa
aaaaaaaaabaaaaaaadaaaaaaaaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaa
adaaaaaaabaaaaaaadadaaaaheaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaa
amamaaaahnaaaaaaaaaaaaaaaaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfa
gphdgjhegjgpgoaafeeffiedepepfceeaaedepemepfcaaklepfdeheocmaaaaaa
abaaaaaaaiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaa
fdfgfpfegbhcghgfheaaklklfdeieefcmmabaaaaeaaaaaaahdaaaaaafjaaaaae
egiocaaaaaaaaaaaagaaaaaafjaaaaaeegiocaaaabaaaaaaabaaaaaafkaaaaad
aagabaaaaaaaaaaafkaaaaadaagabaaaabaaaaaafibiaaaeaahabaaaaaaaaaaa
ffffaaaafibiaaaeaahabaaaabaaaaaaffffaaaagcbaaaaddcbabaaaabaaaaaa
gcbaaaadmcbabaaaabaaaaaagcbaaaadpcbabaaaacaaaaaagfaaaaadpccabaaa
aaaaaaaagiaaaaacacaaaaaadcaaaaaldcaabaaaaaaaaaaaagiacaaaabaaaaaa
aaaaaaaabgifcaaaaaaaaaaaafaaaaaaogbkbaaaabaaaaaaefaaaaajpcaabaaa
aaaaaaaaegaabaaaaaaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaadiaaaaai
hcaabaaaaaaaaaaaagaabaaaaaaaaaaaegiccaaaaaaaaaaaadaaaaaaefaaaaaj
pcaabaaaabaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaa
diaaaaahhcaabaaaaaaaaaaaegacbaaaaaaaaaaapgapbaaaabaaaaaadcaaaaam
hcaabaaaaaaaaaaaegacbaaaaaaaaaaaaceaaaaaaaaamadpaaaamadpaaaamadp
aaaaaaaaegacbaaaabaaaaaadiaaaaaihcaabaaaaaaaaaaaegacbaaaaaaaaaaa
egiccaaaaaaaaaaaaeaaaaaadgaaaaaficaabaaaaaaaaaaaabeaaaaaaaaaiadp
diaaaaahpccabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaadoaaaaab
"
}
SubProgram "d3d11_9x " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_ScrollingTex] 2D 1
ConstBuffer "$Globals" 112
Vector 48 [_tint]
Vector 64 [_Fade]
Float 80 [_YSpeed]
Float 84 [_XSpeed]
ConstBuffer "UnityPerCamera" 128
Vector 0 [_Time]
BindCB  "$Globals" 0
BindCB  "UnityPerCamera" 1
"ps_4_0_level_9_1
eefiecedamfojggnbhgclppbfpfcafolmimfcgnoabaaaaaacaaeaaaaaeaaaaaa
daaaaaaaimabaaaagaadaaaaomadaaaaebgpgodjfeabaaaafeabaaaaaaacpppp
baabaaaaeeaaaaaaacaacmaaaaaaeeaaaaaaeeaaacaaceaaaaaaeeaaaaaaaaaa
abababaaaaaaadaaadaaaaaaaaaaaaaaabaaaaaaabaaadaaaaaaaaaaaaacpppp
fbaaaaafaeaaapkaaaaamadpaaaaiadpaaaaaaaaaaaaaaaabpaaaaacaaaaaaia
aaaaaplabpaaaaacaaaaaaiaabaacplabpaaaaacaaaaaajaaaaiapkabpaaaaac
aaaaaajaabaiapkaabaaaaacaaaaaiiaadaaaakaaeaaaaaeaaaaabiaaaaappia
acaaffkaaaaapplaaeaaaaaeaaaaaciaaaaappiaacaaaakaaaaakklaecaaaaad
aaaacpiaaaaaoeiaabaioekaecaaaaadabaacpiaaaaaoelaaaaioekaafaaaaad
aaaachiaaaaaaaiaaaaaoekaafaaaaadaaaachiaabaappiaaaaaoeiaaeaaaaae
aaaachiaaaaaoeiaaeaaaakaabaaoeiaafaaaaadaaaachiaaaaaoeiaabaaoeka
abaaaaacaaaaciiaaeaaffkaafaaaaadaaaacpiaaaaaoeiaabaaoelaabaaaaac
aaaicpiaaaaaoeiappppaaaafdeieefcmmabaaaaeaaaaaaahdaaaaaafjaaaaae
egiocaaaaaaaaaaaagaaaaaafjaaaaaeegiocaaaabaaaaaaabaaaaaafkaaaaad
aagabaaaaaaaaaaafkaaaaadaagabaaaabaaaaaafibiaaaeaahabaaaaaaaaaaa
ffffaaaafibiaaaeaahabaaaabaaaaaaffffaaaagcbaaaaddcbabaaaabaaaaaa
gcbaaaadmcbabaaaabaaaaaagcbaaaadpcbabaaaacaaaaaagfaaaaadpccabaaa
aaaaaaaagiaaaaacacaaaaaadcaaaaaldcaabaaaaaaaaaaaagiacaaaabaaaaaa
aaaaaaaabgifcaaaaaaaaaaaafaaaaaaogbkbaaaabaaaaaaefaaaaajpcaabaaa
aaaaaaaaegaabaaaaaaaaaaaeghobaaaabaaaaaaaagabaaaabaaaaaadiaaaaai
hcaabaaaaaaaaaaaagaabaaaaaaaaaaaegiccaaaaaaaaaaaadaaaaaaefaaaaaj
pcaabaaaabaaaaaaegbabaaaabaaaaaaeghobaaaaaaaaaaaaagabaaaaaaaaaaa
diaaaaahhcaabaaaaaaaaaaaegacbaaaaaaaaaaapgapbaaaabaaaaaadcaaaaam
hcaabaaaaaaaaaaaegacbaaaaaaaaaaaaceaaaaaaaaamadpaaaamadpaaaamadp
aaaaaaaaegacbaaaabaaaaaadiaaaaaihcaabaaaaaaaaaaaegacbaaaaaaaaaaa
egiccaaaaaaaaaaaaeaaaaaadgaaaaaficaabaaaaaaaaaaaabeaaaaaaaaaiadp
diaaaaahpccabaaaaaaaaaaaegaobaaaaaaaaaaaegbobaaaacaaaaaadoaaaaab
ejfdeheoieaaaaaaaeaaaaaaaiaaaaaagiaaaaaaaaaaaaaaabaaaaaaadaaaaaa
aaaaaaaaapaaaaaaheaaaaaaaaaaaaaaaaaaaaaaadaaaaaaabaaaaaaadadaaaa
heaaaaaaabaaaaaaaaaaaaaaadaaaaaaabaaaaaaamamaaaahnaaaaaaaaaaaaaa
aaaaaaaaadaaaaaaacaaaaaaapapaaaafdfgfpfagphdgjhegjgpgoaafeeffied
epepfceeaaedepemepfcaaklepfdeheocmaaaaaaabaaaaaaaiaaaaaacaaaaaaa
aaaaaaaaaaaaaaaaadaaaaaaaaaaaaaaapaaaaaafdfgfpfegbhcghgfheaaklkl
"
}
}
 }
}
Fallback Off
}